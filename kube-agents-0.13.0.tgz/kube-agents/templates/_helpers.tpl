{{/*
Chart name and version, as the helm.sh/chart label value.
*/}}
{{- define "kube-agents.chart" -}}
{{ printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" }}
{{- end }}

{{/*
Common labels applied to every rendered object.

part-of is a constant, not a template value: it is the key the project-wide
footprint query selects on (-l app.kubernetes.io/part-of=kube-agents), so an
object that renders without it is invisible to every doc'd cleanup and audit
command. See the Resource labels reference page for the contract this shares
with the operator, the kustomizations, and the provisioner.
*/}}
{{- define "kube-agents.labels" -}}
helm.sh/chart: {{ include "kube-agents.chart" . }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/part-of: kube-agents
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}

{{/*
The registry prefix images built from this repo resolve under, or "" to leave
them on their public defaults. Takes the root context.
*/}}
{{- define "kube-agents.imageRegistry" -}}
{{- (.Values.global | default dict).imageRegistry | default "" | trimSuffix "/" -}}
{{- end }}

{{/*
The same for images this project does not build (LiteLLM, fluent-bit). Falls
back to imageRegistry, since a single-prefix mirror is the common case and a
chart that mirrored only its own images would render a half-mirrored install —
the operator handing its managed pods public references after `helm install`
reported success.

This deliberately does NOT match third_party_registry_prefix in
scripts/installer/common.sh, which requires THIRD_PARTY_REGISTRY_PREFIX
explicitly. The asymmetry is about history, not preference: REGISTRY_PREFIX
shipped before this inventory existed and has always meant "the registry
holding the images this project builds", so widening it would redirect working
installs to images their mirror was never given. global.imageRegistry is new
here and carries no such promise, so it can take the safer default.

Takes the root context.
*/}}
{{- define "kube-agents.thirdPartyImageRegistry" -}}
{{- $g := .Values.global | default dict -}}
{{- $g.thirdPartyImageRegistry | default $g.imageRegistry | default "" | trimSuffix "/" -}}
{{- end }}

{{/*
One global.imagePullSecrets entry, as a Secret name.

Both spellings are accepted: the bare name, so a single secret is reachable
with --set global.imagePullSecrets[0]=regcred, and the {name: x} map that
Kubernetes' own PodSpec and most charts' global.imagePullSecrets take. The map
is the shape people write first, and rendering one straight into a value gives
the Secret name "map[name:regcred]" -- which the API server accepts, the
kubelet cannot find, and nothing anywhere reports as wrong. Anything else stops
the render, because the alternative is the same silent failure by another
route.

Takes one entry, not the root context.
*/}}
{{- define "kube-agents.imagePullSecretName" -}}
{{- if kindIs "string" . -}}
{{ required "global.imagePullSecrets: an entry cannot be an empty Secret name" . }}
{{- else if kindIs "map" . -}}
{{ required (printf "global.imagePullSecrets: a map entry needs a non-empty `name`; this one has keys [%s]" (join " " (keys .))) .name }}
{{- else -}}
{{ fail (printf "global.imagePullSecrets entries must be a Secret name or {name: <secret>}, got a %s" (kindOf .)) }}
{{- end -}}
{{- end }}

{{/*
The pod-level imagePullSecrets block, or nothing at all when
global.imagePullSecrets is empty.

Returns the whole block including its key, so callers write
`{{- with (include "kube-agents.imagePullSecrets" .) }}{{ . | nindent N }}{{- end }}`
and an unset value adds no stray blank line. Same contract as
kube-agents.compactFields, and the same reason: every pod spec the chart
renders and the PlatformAgent CR have to agree on this, and a hand-written `if`
at each of them is one place for the next reader to forget.

Takes the root context.
*/}}
{{- define "kube-agents.imagePullSecrets" -}}
{{- with (.Values.global | default dict).imagePullSecrets -}}
imagePullSecrets:
{{- range . }}
  - name: {{ include "kube-agents.imagePullSecretName" . | quote }}
{{- end }}
{{- end }}
{{- end }}

{{/*
The same names, comma-joined for the operator's IMAGE_PULL_SECRETS env var, or
the empty string when there are none -- falsy, so callers can `with` it.

Takes the root context.
*/}}
{{- define "kube-agents.imagePullSecretNames" -}}
{{- $names := list -}}
{{- range (.Values.global | default dict).imagePullSecrets -}}
{{- $names = append $names (include "kube-agents.imagePullSecretName" .) -}}
{{- end -}}
{{- join "," $names -}}
{{- end }}

{{/*
Rewrite an image repository onto a registry prefix, keeping only the trailing
image name: quay.io/jetstack/cert-manager-webhook under "reg.example.com/m"
becomes reg.example.com/m/cert-manager-webhook. That flat layout is what
scripts/mirror_images.sh writes and what the operator assumes when it derives
the credential-proxy reference from the agent one. An empty registry returns
the repository untouched, so a default install renders byte-identically.

The trailing segment is a stand-in for the real rule. mirror_images.sh names
each destination after the images.json entry's .name, and a chart cannot read
images.json at render time, so this reproduces it by convention rather than by
lookup. An image whose inventory name differs from its trailing segment
(hindsight-postgresql is docker.io/pgvector/pgvector) cannot use this helper —
kube-agents.thirdPartyImage below takes the real name explicitly. Check 3c in
hack/check-image-inventory.sh fails the build when a rendered mirror name is
not an inventory name, which is what keeps the shortcut safe.

Takes a dict: {repository, registry}. Returns the repository only — the
PlatformAgent CR carries repository and tag in separate fields, so joining
them here would not suit every caller.
*/}}
{{- define "kube-agents.imageRepository" -}}
{{- $registry := .registry | default "" | trimSuffix "/" -}}
{{- if $registry -}}
{{- printf "%s/%s" $registry (.repository | splitList "/" | last) -}}
{{- else -}}
{{- .repository -}}
{{- end -}}
{{- end }}

{{/*
A complete third-party image reference: mirrored installs pull <prefix>/<name>:<tag>
with any @sha256 digest dropped — `make mirror-images` pushes by tag, and the
copy's digest differs from the upstream one, so keeping it would break every
mirrored pull — while unmirrored installs pull the inventory's full pin,
digest and all.

`name` is the images.json entry name, which is what mirror_images.sh names the
destination; it defaults to the repository's trailing segment, the common case
where the two agree. Passing it explicitly is what lets an image like
hindsight-postgresql (docker.io/pgvector/pgvector) render correctly under a
mirror.

Takes a dict: {repository, tag, name (optional), root (the root context)}.
*/}}
{{- define "kube-agents.thirdPartyImage" -}}
{{- $registry := include "kube-agents.thirdPartyImageRegistry" .root -}}
{{- if $registry -}}
{{- printf "%s/%s:%s" $registry (.name | default (.repository | splitList "/" | last)) (.tag | splitList "@" | first) -}}
{{- else -}}
{{- printf "%s:%s" .repository .tag -}}
{{- end -}}
{{- end }}

{{/*
Whether the Hindsight memory store renders. hindsight.enabled is a tri-state:
true and false are answers, and null (the default) follows the agent's memory
provider — the providers that need the Hindsight API get it, everything else
does not, so an install cannot select hindsight memory and silently receive
no store.
*/}}
{{- define "kube-agents.hindsightEnabled" -}}
{{- $explicit := .Values.hindsight.enabled -}}
{{- if kindIs "invalid" $explicit -}}
{{- $provider := ((.Values.platformAgent.harness.memory | default dict).provider) | default "" -}}
{{- if or (eq $provider "kube_agents_memory") (eq $provider "hindsight") -}}
true
{{- end -}}
{{- else if $explicit -}}
true
{{- end -}}
{{- end }}

{{/*
Whether the agent's PodMonitorings render, the gateway's and the credential
broker's. platformAgent.podMonitoring is a
tri-state: true and false are answers, and null (the default) follows the
cluster — the PodMonitoring API is served where GKE Managed Prometheus is
installed and nowhere else, so an install on a cluster without it takes no
object it cannot apply. helm template alone has no cluster to ask: pass
--api-versions monitoring.googleapis.com/v1/PodMonitoring to see the default
render, or --validate to ask the cluster the kubeconfig points at.
*/}}
{{- define "kube-agents.platformAgentPodMonitoring" -}}
{{- $explicit := .Values.platformAgent.podMonitoring -}}
{{- if kindIs "invalid" $explicit -}}
{{- if .Capabilities.APIVersions.Has "monitoring.googleapis.com/v1/PodMonitoring" -}}
true
{{- end -}}
{{- else if $explicit -}}
true
{{- end -}}
{{- end }}

{{/*
The OTLP/HTTP collector base URL for the chart's own consumers (the LiteLLM exporter).

Unset means the GKE Managed OpenTelemetry collector, which is what these consumers have
always used. The operator has a richer answer available — it can discover a collector at
reconcile time — but Helm renders once, before any of that, so it keeps the historical
default rather than guessing.
*/}}
{{- define "kube-agents.otlpEndpoint" -}}
{{- .Values.telemetry.otlpEndpoint | default "http://opentelemetry-collector.gke-managed-otel.svc.cluster.local:4318" -}}
{{- end }}

{{/*
The namespace to open OTLP egress to, for the LiteLLM NetworkPolicy.

A namespaceSelector cannot be derived at reconcile time the way the agent's endpoint can:
it has to be right when the policy is applied. So it comes from telemetry.collectorNamespace
when given, and otherwise from the endpoint host, which is a cluster-local Service name in
the case this feature exists for (<svc>.<ns>.svc.cluster.local, or the shortened <svc>.<ns>).

Anything else — an external vendor endpoint, a bare hostname — has no namespace to open,
and what the static policy does then follows the operator's dynamic copy. With
litellm.otel on, this renders "" and the caller emits no OTLP rule: the exporter goes out
over the port-443 rule, which kube-agents.litellmOTLPPortCheck has already made sure is
where the endpoint listens, and a made-up namespaceSelector would open 4317/4318 to a
namespace nothing exports to. With litellm.otel off (the default) there is no LiteLLM
exporter, and the rule keeps the shipping gke-managed-otel default rather than changing
a policy over an egress rule nothing uses.

Only the static litellm-policy render calls this. On the default install the operator
owns the policy and resolves the namespace at reconcile time from the CR.
*/}}
{{- define "kube-agents.otlpCollectorNamespace" -}}
{{- if .Values.telemetry.collectorNamespace -}}
{{- .Values.telemetry.collectorNamespace -}}
{{- else if not .Values.telemetry.otlpEndpoint -}}
gke-managed-otel
{{- else if include "kube-agents.otlpEndpointIsClusterLocal" . -}}
{{- index (splitList "." (include "kube-agents.otlpEndpointHost" .)) 1 -}}
{{- else if not .Values.litellm.otel -}}
gke-managed-otel
{{- end -}}
{{- end }}

{{/*
The host[:port] of telemetry.otlpEndpoint: scheme and path stripped, nothing else.
*/}}
{{- define "kube-agents.otlpEndpointHostPort" -}}
{{- $hostport := .Values.telemetry.otlpEndpoint | trimPrefix "https://" | trimPrefix "http://" -}}
{{- splitList "/" $hostport | first -}}
{{- end }}

{{/*
The host of telemetry.otlpEndpoint, parsed exactly the way the operator's
otlpCollectorNamespace (k8s-operator, platformagent_manifests.go) parses the same value
when it builds the dynamic policy: exact lowercase scheme prefixes, cut at the first "/",
then at the first ":". The two renders have to reach the same verdict about the same
endpoint, so this deliberately inherits the operator's blind spots rather than being
smarter than it — a bracketed IPv6 literal cuts at its first colon and reads as external
on both sides, a query string stays in the last label on both sides. Anything this leaves
unreadable is refused by kube-agents.litellmOTLPPortCheck instead of guessed at.
*/}}
{{- define "kube-agents.otlpEndpointHost" -}}
{{- include "kube-agents.otlpEndpointHostPort" . | splitList ":" | first -}}
{{- end }}

{{/*
"true" when telemetry.otlpEndpoint names an in-cluster Service, "" otherwise — the one
place that heuristic lives, so the namespace helper and the port check cannot drift.

Only two shapes are an in-cluster Service: exactly <svc>.<ns>, or <svc>.<ns>.svc[...].
Anything with a third label that is not "svc" is a public DNS name, and reading its
second label as a namespace would quietly open egress to a namespace named "vendor".
*/}}
{{- define "kube-agents.otlpEndpointIsClusterLocal" -}}
{{- $parts := splitList "." (include "kube-agents.otlpEndpointHost" .) -}}
{{- if or (eq (len $parts) 2) (and (ge (len $parts) 3) (eq (index $parts 2) "svc")) -}}
true
{{- end -}}
{{- end }}

{{/*
Fails the render when the LiteLLM OTLP exporter points at an external host that
litellm-policy cannot reach, whoever renders that policy.

Neither copy of the policy has a rule for an external host except port 443, and with no
collector namespace configured the operator emits no OTLP rule at all for an endpoint
that is not an in-cluster Service. So an external endpoint on any other port (an OTLP
vendor's 4317/4318 ingress, say) renders green and exports nothing, and the only signal
is an operator log line. This catches it at render time. Renders nothing; it is
included unconditionally and acts only when litellm.otel is on — the check is about
LiteLLM's exporter, which does not exist otherwise — and litellm.networkPolicy is on,
since with it off nothing blocks. An explicit telemetry.collectorNamespace is the user
asserting the collector is in-cluster whatever its host looks like (an IP literal, a
bare Service name), and both renders then open 4317/4318 to that namespace, so the
check stands aside for it. It also stands aside for an in-cluster host on a port other
than 4317/4318, on purpose: the URL carries the Service port and the policy sees the
targetPort, so a Service mapping 9999 to 4318 works and a fail there would be wrong.

Two host shapes are refused even on 443, because the 443 rule excepts private ranges
and they are decidable at render time: an IP literal inside a range that render's 443
rule excepts, and a single-label hostname, which resolves through the Pod's search
domain to a Service in its own namespace. Both are in-cluster collectors in disguise,
and telemetry.collectorNamespace is the remedy, as it was before this check existed.
The two rules except different ranges — the static copy the three RFC 1918 blocks and
nothing over IPv6, the operator's those plus CGNAT and link-local space, and over IPv6
unique-local, link-local and multicast — so the check refuses exactly what the rule it
is standing in for does not reach, and nothing else: a loopback literal is excepted by
neither and renders. A DNS name that happens to resolve to private space is not
decidable here, and the docs say so.
*/}}
{{- define "kube-agents.litellmOTLPPortCheck" -}}
{{- /*
  The switches that leave LiteLLM unselected, in every render, so that nothing blocks:
  litellm.networkPolicy=false stops both renders; on the operator-owned render the CR's
  spec.networkPolicy.enabled=false and the enable-litellm-network-policy: "false"
  annotation each delete the managed copy. On that render a collector namespace
  supplied through platformAgent.annotations counts the same as
  telemetry.collectorNamespace, because the operator opens 4317/4318 to it; the static
  render reads only the value, so there the annotation opens nothing and does not count.
*/ -}}
{{- $crAnnotations := .Values.platformAgent.annotations | default dict -}}
{{- $crNetworkPolicy := .Values.platformAgent.networkPolicy | default dict -}}
{{- $operatorOwned := and .Values.platformAgent.enabled .Values.operator.enabled -}}
{{- /* The operator reads both annotations trimmed, and the opt-out case-insensitively. */ -}}
{{- $optOutAnnotation := get $crAnnotations "kubeagents.x-k8s.io/enable-litellm-network-policy" | toString | trim | lower -}}
{{- $crOptOut := and $operatorOwned (or (and (kindIs "bool" $crNetworkPolicy.enabled) (not $crNetworkPolicy.enabled)) (eq $optOutAnnotation "false")) -}}
{{- /*
  Everything below, the namespace validations included, is about LiteLLM's exporter
  being blocked by litellm-policy, so all of it stands aside when there is no exporter
  or no policy that selects LiteLLM: a mistyped namespace with the exporter off blocks
  nothing, and failing the render for it would cite a rule that serves no traffic.
*/ -}}
{{- $checkApplies := and .Values.litellm.otel .Values.litellm.networkPolicy (not $crOptOut) -}}
{{- /*
  Both namespace routes are checked as a namespace name, a lowercase RFC 1123 label.
  That is tighter than the label-value rule the operator applies to the annotation,
  deliberately: a value the operator discards would stand this check aside and open
  nothing, and a value it keeps that no namespace can be called (Obs_NS is a valid label
  value) would open 4317/4318 to a namespace that cannot exist. Either way the exporter
  is blocked, and either way the render is the place to say so.
*/ -}}
{{- $namespaceNamePattern := "^[a-z0-9]([-a-z0-9]{0,61}[a-z0-9])?$" -}}
{{- $namespaceAnnotation := get $crAnnotations "kubeagents.x-k8s.io/otlp-collector-namespace" | toString | trim -}}
{{- if and $checkApplies $operatorOwned $namespaceAnnotation (not (regexMatch $namespaceNamePattern $namespaceAnnotation)) -}}
{{- fail (printf "platformAgent.annotations[\"kubeagents.x-k8s.io/otlp-collector-namespace\"]=%q is not a valid namespace name (a lowercase RFC 1123 label), so the operator would either ignore it or open OTLP egress to a namespace that cannot exist, and the LiteLLM OTLP exporter (litellm.otel=true) would be blocked. Give the collector's namespace name." $namespaceAnnotation) -}}
{{- end -}}
{{- /*
  The value route gets the same validation: an invalid namespace would stand this check
  aside, be stamped on the CR, and select nothing in either render.
*/ -}}
{{- $collectorNamespaceValue := .Values.telemetry.collectorNamespace | toString | trim -}}
{{- if and $checkApplies $collectorNamespaceValue (not (regexMatch $namespaceNamePattern $collectorNamespaceValue)) -}}
{{- fail (printf "telemetry.collectorNamespace=%q is not a valid namespace name (a lowercase RFC 1123 label), so the NetworkPolicy would select nothing and the LiteLLM OTLP exporter (litellm.otel=true) would be blocked. Give the collector's namespace name." $collectorNamespaceValue) -}}
{{- end -}}
{{- $collectorNamespace := or $collectorNamespaceValue (and $operatorOwned $namespaceAnnotation) -}}
{{- if and $checkApplies .Values.telemetry.otlpEndpoint (not $collectorNamespace) (not (include "kube-agents.otlpEndpointIsClusterLocal" .)) -}}
{{- $endpoint := .Values.telemetry.otlpEndpoint -}}
{{- /*
  A scheme this parser does not strip (grpc://, or HTTP:// in capitals) would leave a
  hostport with no port to read and pass as an implicit 443. LiteLLM's exporter speaks
  OTLP/HTTP over http:// or https://, so anything else is refused here rather than
  waved through.
*/ -}}
{{- if and (contains "://" $endpoint) (not (or (hasPrefix "http://" $endpoint) (hasPrefix "https://" $endpoint))) -}}
{{- fail (printf "telemetry.otlpEndpoint %q must start with http:// or https:// (lowercase): the LiteLLM OTLP exporter (litellm.otel=true) speaks OTLP/HTTP, and the NetworkPolicy render cannot read the port off any other scheme." $endpoint) -}}
{{- end -}}
{{- $hostport := include "kube-agents.otlpEndpointHostPort" . -}}
{{- /*
  The port is whatever follows the first ":" once a bracketed IPv6 literal is set aside,
  and it has to be all digits. Userinfo, a query string, or a fragment in the authority
  would leave the port unreadable (and the operator would read the host differently),
  so those are refused too rather than passed as an implicit 443.
*/ -}}
{{- $afterHost := regexReplaceAll "^\\[[^\\]]*\\]" $hostport "" -}}
{{- $port := "" -}}
{{- if contains ":" $afterHost -}}
{{- $port = splitList ":" $afterHost | rest | join ":" -}}
{{- end -}}
{{- if or (regexMatch "[?#@]" $hostport) (and (contains ":" $afterHost) (not (regexMatch "^[0-9]+$" $port))) -}}
{{- fail (printf "telemetry.otlpEndpoint %q: the NetworkPolicy render cannot read the port off it. Give it as http(s)://host[:port][/path], with no userinfo, query, or fragment." $endpoint) -}}
{{- end -}}
{{- if not $port -}}
{{- $port = ternary "80" "443" (hasPrefix "http://" $endpoint) -}}
{{- end -}}
{{- $host := include "kube-agents.otlpEndpointHost" . -}}
{{- /*
  The prefixes each render's 443 rule excepts, and only those: RFC 1918 in the static
  copy (litellm.yaml); RFC 1918, CGNAT and link-local in the operator's
  (platformagent_manifests.go). Change one alongside its rule.
*/ -}}
{{- $rfc1918Prefixes := "10\\.|192\\.168\\.|172\\.(1[6-9]|2[0-9]|3[01])\\." -}}
{{- $operatorOnlyPrefixes := "|169\\.254\\.|100\\.(6[4-9]|[7-9][0-9]|1[01][0-9]|12[0-7])\\." -}}
{{- $exceptedPrefixes := ternary (printf "%s%s" $rfc1918Prefixes $operatorOnlyPrefixes) $rfc1918Prefixes $operatorOwned -}}
{{- $privateIPv4 := regexMatch (printf "^(%s)[0-9]+\\.[0-9]+(\\.[0-9]+)?$" $exceptedPrefixes) $host -}}
{{- /*
  The operator's ::/0 peer excepts fc00::/7, fe80::/10 and ff00::/8, all decidable off
  a bracketed literal's first hextet. The static copy has no IPv6 peer at all, and
  refuses every IPv6 literal further down.
*/ -}}
{{- $privateIPv6 := and $operatorOwned (regexMatch "^\\[(?i:f[cd]|fe[89ab]|ff)" $hostport) -}}
{{- /* A bracketed IPv6 literal cuts to "[…" with no dot; it is not a single-label host. */ -}}
{{- $singleLabel := and (not (contains "." $host)) (not (hasPrefix "[" $hostport)) -}}
{{- if or $privateIPv4 $privateIPv6 $singleLabel -}}
{{- $shape := "a single-label host" -}}
{{- if $privateIPv4 -}}{{- $shape = "a private IPv4 address" -}}{{- else if $privateIPv6 -}}{{- $shape = "a private IPv6 address" -}}{{- end -}}
{{- fail (printf "telemetry.otlpEndpoint %q names %s, which litellm-policy's port-443 rule does not reach (it excepts private ranges), so the LiteLLM OTLP exporter (litellm.otel=true) would be blocked. If this is an in-cluster collector, set telemetry.collectorNamespace to its namespace; otherwise give the collector's public host." $endpoint $shape) -}}
{{- end -}}
{{- /* The static copy's 443 rule has an IPv4 peer only; the operator's adds ::/0. */ -}}
{{- if and (hasPrefix "[" $hostport) (not $operatorOwned) -}}
{{- fail (printf "telemetry.otlpEndpoint %q is an IPv6 literal, and the static litellm-policy's port-443 rule reaches IPv4 destinations only, so the LiteLLM OTLP exporter (litellm.otel=true) would be blocked. Give the collector's hostname, or set litellm.networkPolicy=false if the policy is managed elsewhere." $endpoint) -}}
{{- end -}}
{{- if ne $port "443" -}}
{{- fail (printf "telemetry.otlpEndpoint %q names an external host on port %s, but litellm-policy permits egress to external hosts on port 443 only, so the LiteLLM OTLP exporter (litellm.otel=true) would be blocked. Use a port-443 endpoint, set telemetry.collectorNamespace if the collector is in fact in-cluster, or set litellm.networkPolicy=false if the policy is managed elsewhere." $endpoint $port) -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
Renders a dict of optional CR fields as YAML, dropping the ones left unset.

"Unset" is null or the empty string; `false` and `0` are values and survive,
which is the whole reason this exists — `with` and plain truthiness drop both,
and a boolean knob nobody can set to false is not a knob.

Returns the empty string when every field is unset, so a caller can write
`{{- with (include ...) }}` and have the PARENT block disappear too. That
coupling is the point: guarding a parent by hand means enumerating its children
in an `or`, and the failure mode when a later field is added to one list and not
the other is silence — the template still emits valid YAML, just without the
field somebody set.

Takes a dict of field name to value.
*/}}
{{- define "kube-agents.compactFields" -}}
{{- $out := dict -}}
{{- range $key, $value := . -}}
{{- if not (or (kindIs "invalid" $value) (and (kindIs "string" $value) (eq $value ""))) -}}
{{- $_ := set $out $key $value -}}
{{- end -}}
{{- end -}}
{{- if $out -}}
{{- toYaml $out -}}
{{- end -}}
{{- end }}

{{/*
The LiteLLM gateway config, mirroring
k8s-operator/config/integrations/litellm/base/config.yaml and its provider
overlays.

Defined once and consumed twice — as the ConfigMap body and as the input to the
Deployment's checksum annotation — because those two must not be able to
disagree. Hashing the inputs (provider, model, callbacks) instead of the output
was the earlier shape and it missed any edit to this template itself: the
ConfigMap changed, the checksum did not, the Deployment did not roll. The
gateway mounts this with subPath, and a subPath ConfigMap mount never receives
in-place updates, so the running pod would have kept the old file indefinitely.

Takes a dict of provider, model, callbacks, and maxTokens (optional; 0 or
absent renders no max_tokens), plus the optional reasoningEffort, dropParams,
fallback (a dict of modelName and reasoningEffort), timeoutSeconds and
numRetries. Every optional input renders nothing when unset, so the default
render is unchanged.
*/}}
{{- define "kube-agents.litellmConfig" -}}
{{- /*
  max_tokens on every alias when .maxTokens is above zero, and no key at all
  otherwise, so the default render matches the kustomize base
  (k8s-operator/config/integrations/litellm/base/config.yaml), which carries
  no such key on purpose. One value for all three aliases: they are one
  upstream model, and the budget is the backend's property, not the alias's.
  LiteLLM's router spreads litellm_params underneath the request's own
  arguments, so this is what a request that names no max_tokens gets, not a
  ceiling on one that does; values.yaml says what that means for the agent.

  reasoning_effort follows the same rule: on every alias when set, and on a
  fourth alias, <model>-<effort>, that names it. The fallback alias, when
  asked for, is one more entry for the same upstream model at its own effort,
  and router_settings.fallbacks sends each primary alias to it once the
  primary's retries are spent.
*/}}
{{- $maxTokens := int (.maxTokens | default 0) -}}
{{- /*
  Recent Claude models (Opus 5 among them) answer temperature, top_p and top_k
  with a 400 ("`temperature` is deprecated for this model"), and LiteLLM
  refuses a temperature other than 1 for them before the request leaves the
  gateway. A caller does not have to be configured by this chart to send one:
  Hindsight needed its own opt-out (hindsight.yaml), and Hermes's auxiliary
  title generator sent temperature until the profiles disabled it. LiteLLM's
  per-deployment additional_drop_params
  strips the named keys from a request before the provider sees it, whatever
  the caller sent, so the gateway covers every caller at once. Every Claude
  model, not only the ones that refuse: a name test that tracked which do
  would break on each new release, and an older Claude losing a caller's
  sampling override is a quieter failure than a 400. Claude only: anthropic
  serves nothing else, vertex_ai serves Claude under claude-* names, and a
  Gemini or OpenAI render stays byte-identical.
*/}}
{{- $claude := or (eq .provider "anthropic") (and (eq .provider "vertex_ai") (hasPrefix "claude-" .model)) -}}
{{- $effort := .reasoningEffort | default "" -}}
{{- $fallback := .fallback | default dict -}}
{{- $fallbackEffort := $fallback.reasoningEffort | default "" -}}
{{- $fallbackName := "" -}}
{{- if $fallbackEffort -}}
{{- $fallbackName = $fallback.modelName | default (printf "%s-%s" .model $fallbackEffort) -}}
{{- end -}}
{{- $timeout := int (.timeoutSeconds | default 0) -}}
{{- $numRetries := int (.numRetries | default 0) -}}
{{- $primaries := list "model-default" "hermes-agent" .model -}}
{{- if $effort -}}
{{- $primaries = append $primaries (printf "%s-%s" .model $effort) -}}
{{- end -}}
{{- if and $fallbackName (has $fallbackName $primaries) -}}
{{- fail (printf "litellm.fallback.modelName %q is already a primary alias (%s); a model cannot fall back to itself" $fallbackName (join ", " $primaries)) -}}
{{- end -}}
model_list:
{{- range $primaries }}
  - model_name: {{ . }}
    litellm_params:
      model: {{ printf "%s/%s" $.provider $.model }}
      {{- if gt $maxTokens 0 }}
      max_tokens: {{ $maxTokens }}
      {{- end }}
      {{- if $effort }}
      reasoning_effort: {{ $effort }}
      {{- end }}
      {{- if $claude }}
      additional_drop_params: ["temperature", "top_p", "top_k"]
      {{- end }}
{{- end }}
{{- if $fallbackName }}
  - model_name: {{ $fallbackName }}
    litellm_params:
      model: {{ printf "%s/%s" .provider .model }}
      {{- if gt $maxTokens 0 }}
      max_tokens: {{ $maxTokens }}
      {{- end }}
      reasoning_effort: {{ $fallbackEffort }}
      {{- if $claude }}
      additional_drop_params: ["temperature", "top_p", "top_k"]
      {{- end }}
{{- end }}
litellm_settings:
  {{- if .dropParams }}
  drop_params: true
  {{- end }}
  callbacks: {{ .callbacks }}
{{- /*
  Prompt caching, for Anthropic-family models only: the same $claude gate as
  additional_drop_params above. On Gemini, LiteLLM turns these markers into
  Vertex explicit context caching: a cachedContents list before every call,
  and a create whenever the cached prefix is new. A create that Vertex holds
  past its request credential's life fails the whole turn (a 401 after a
  ten-minute stall in the incident that found this), and Gemini's
  implicit caching needs no markers. The kustomize base carries the same block
  only in its anthropic overlay; see that file for why the breakpoints live
  here rather than in the agent's own config.
*/}}
{{- if or $claude $fallbackName (gt $timeout 0) (gt $numRetries 0) }}
router_settings:
  {{- if $fallbackName }}
  fallbacks:
    {{- range $primaries }}
    - {{ . }}: [{{ $fallbackName }}]
    {{- end }}
  {{- end }}
  {{- if gt $timeout 0 }}
  timeout: {{ $timeout }}
  {{- end }}
  {{- if gt $numRetries 0 }}
  num_retries: {{ $numRetries }}
  {{- end }}
  {{- if $claude }}
  default_litellm_params:
    cache_control_injection_points:
      - location: message
        role: system
        control:
          type: ephemeral
          ttl: 1h
      - location: message
        index: -3
      - location: message
        index: -1
  {{- end }}
{{- end }}
{{- end }}

{{/*
Selector labels for the operator Deployment. Kept minimal and stable:
selectors are immutable once the Deployment exists.
*/}}
{{- define "kube-agents.operatorSelectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}-operator
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{/*
topologySpreadConstraints for a multi-replica workload this chart owns.

Renders nothing below two replicas, so the operator gets the field only if
someone raises operator.replicaCount. A constraint over a single pod is
satisfied by construction, and printing it would leave a reader working out that
it means nothing. Hindsight has no call site at all for the same reason taken
further: both its workloads carry a literal `replicas: 1` with no value behind
it, so a call there could never render and would read as coverage it does not
have.

The chart shipped PDBs and a default replicaCount of 2 for litellm and
github-token-minter without this, and the Workload Reliability Audit in this
repository found both on 2026-09-06: "replicas=2, no topologySpreadConstraints
or podAntiAffinity". The PDB does not cover the gap it names. maxUnavailable: 1
stalls a *drain* that would take both replicas, but a node that fails takes
whatever is on it, and nothing was keeping the two pods apart.

ScheduleAnyway, not DoNotSchedule — obtainability_audit_sop.md 3.8 calls that
mandatory, and the reason is the shape of the clusters this chart installs into.
A pool that cannot satisfy maxSkew: 1 leaves the second replica Pending
indefinitely, which is worse than the co-location this exists to avoid.

kubernetes.io/hostname and not the zone key, for the same section's reason: the
loss this guards against is a node going away under a drain or a repair, and a
zonal cluster has one zone to spread across.

The selector is the workload's own and is passed in rather than derived, as
already-rendered YAML rather than a dict so the operator can hand over
`kube-agents.operatorSelectorLabels` verbatim instead of a second copy of it. A
labelSelector that does not match the pods the constraint is attached to counts
some other population and skews against it; these selectors are also immutable
once the Deployment exists, so the caller is the only thing that knows the right
answer. Keep each call in step with its Deployment's spec.selector, the way
pdb.yaml's selectors already have to be.

matchLabelKeys scopes the skew to one ReplicaSet. Without it the constraint
counts old and new pods together during a rollout, and with maxSurge: 1,
maxUnavailable: 1 and two nodes holding one replica each, the surge pod lands
beside an old one, the controller prefers to delete the old pod that shares a
node, and the second new pod then sees a tie and can land on the same node —
both live replicas on one node until the next rollout, which the constraint
exists to prevent. Every image pin, config checksum or resource change is a
rollout, so this is ordinary use. pod-template-hash is the label the
Deployment controller stamps per revision; the field is on by default from
Kubernetes 1.27, inside the chart's 1.29 floor.
*/}}
{{- define "kube-agents.topologySpreadConstraints" -}}
{{- if and .enabled (gt (int .replicas) 1) -}}
topologySpreadConstraints:
  - maxSkew: 1
    topologyKey: kubernetes.io/hostname
    whenUnsatisfiable: ScheduleAnyway
    matchLabelKeys:
      - pod-template-hash
    labelSelector:
      matchLabels:
        {{- .selectorLabels | nindent 8 }}
{{- end }}
{{- end }}

{{- /*
The providers of the forges the install declares, comma-separated and
deduplicated, folding the deprecated `integration.github` alias in as one
`github` forge. Two spellings of one setting is how a values file ends up
declaring one forge and provisioning another's credentials, so nothing reads
the forge values directly to decide which forge this is -- everything calls
this, and the minter guard is the reason it has to be one answer.

It also carries the checks the chart can make before the API server does, so
the failure names the values key: the two spellings are exclusive, forge names
are unique, a provider must be registered, a GitHub forge's host must be github.com or a GitHub
Enterprise Server hostname and its namespace a GitHub organisation or user name, an install has
one GitHub host and one host is one forge's, a GitLab forge needs a
credentialsRef, a host that is a hostname and not GitHub's, and a namespace that
is a GitLab group path, a self-managed forge (gitea) must name its host, only a
self-managed forge may declare a port or plain http, and a repository must name a
declared forge, be neither empty nor the alias's `None`, and be qualified by a
namespace if it is a bare name; and at most one repository has role gitops. The namespace checks matter beyond the error
text: a single-forge declaration renders as the alias, so without them the
refusal would name `github.org` or `github.gitRepo`, keys the values file never
set.

A self-managed forge has no fixed host list: the host it serves is the one its
declaration names, so the "host and no repository" test below compares a
repository against that host rather than against GitHub's spellings.

Renders the empty string when no forge is declared at all, which is a valid
install: repositories can be registered in the gitops-state ConfigMap later.
`gitRepo: None` is the alias's sentinel for "no repository", so on its own it
declares nothing -- reading it as a declaration would make it collide with the
`forges` list that replaces it, which is the migration every install has to
make.

The provider list mirrors the CRD's enum on ForgeSpec.Provider, the
self-managed list mirrors the providers with SelfManaged set, the host list
mirrors githubHosts, and the GitLab namespace pattern mirrors
gitlabNamespaceRegex, all in k8s-operator/api/v1alpha1.
*/}}
{{- define "kube-agents.forgeProviders" -}}
{{- $registered := list "github" "gitlab" "gitea" -}}
{{- $selfManaged := list "gitea" -}}
{{- $defaultScheme := "https" -}}
{{- $githubHosts := list "github.com" "www.github.com" "ssh.github.com" -}}
{{- $integ := .Values.platformAgent.integration -}}
{{- $forges := $integ.forges | default list -}}
{{- $repos := $integ.repositories | default list -}}
{{- $github := $integ.github | default dict -}}
{{- $gitRepo := $github.gitRepo | default "" -}}
{{- $githubSet := or $github.org (and $gitRepo (ne $gitRepo "None")) -}}
{{- if and (or $forges $repos) $githubSet -}}
{{- fail "set platformAgent.integration.forges and repositories, or platformAgent.integration.github, not both; github is a deprecated alias for one forge with provider: github" -}}
{{- end -}}
{{- $names := list -}}
{{- $providers := list -}}
{{- $namespaces := dict -}}
{{- $gitlabHosts := dict -}}
{{- $hostProviders := dict -}}
{{- $ghHost := "" -}}
{{- $ghCA := "" -}}
{{- /* Mirrors the github provider's ReservedDomains. */ -}}
{{- $githubReserved := "(^|\\.)(github\\.com|githubusercontent\\.com|githubassets\\.com|githubapp\\.com|github\\.io|github\\.dev|ghe\\.com)$" -}}
{{- $forgeHosts := dict -}}
{{- range $i, $f := $forges -}}
{{- if not $f.name -}}
{{- fail (printf "platformAgent.integration.forges[%d].name is required" $i) -}}
{{- end -}}
{{- if has $f.name $names -}}
{{- fail (printf "platformAgent.integration.forges[%d].name %q is already declared; each forge needs its own name" $i $f.name) -}}
{{- end -}}
{{- $provider := $f.provider | default "github" -}}
{{- if not (has $provider $registered) -}}
{{- fail (printf "platformAgent.integration.forges[%d].provider is %q; must be one of %s" $i $provider (join ", " $registered)) -}}
{{- end -}}
{{- $host := $f.host | default "" -}}
{{- /* ASCII only before `lower`, which is Unicode: `gİthub.com` lowers to github.com, and the operator folds ASCII only, so it is another host. */ -}}
{{- /* A github forge is at github.com in one of its spellings, or at a GitHub Enterprise Server host: a hostname, label by label, that is not under a domain where GitHub runs its own services and not GitLab's. */ -}}
{{- if and (eq $provider "github") $host (not (and (regexMatch "^[A-Za-z0-9.-]+$" $host) (has (lower $host) $githubHosts))) (or (not (regexMatch "^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$" $host)) (gt (len $host) 253) (regexMatch $githubReserved (lower $host)) (regexMatch "(^|\\.)gitlab\\.com$" (lower $host))) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host is %q, which provider github does not serve: name github.com or a GitHub Enterprise Server host" $i $f.host) -}}
{{- end -}}
{{- /* A forge at a host other than github.com names its provider, as the CRD's rule: left to the default, a forge written for a GitLab instance would become a GitHub Enterprise Server. */ -}}
{{- if and (not $f.provider) $host (not (has (lower $host) $githubHosts)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].provider is required: the forge is at %q, not github.com; name it github for a GitHub Enterprise Server or gitlab for a GitLab instance" $i $f.host) -}}
{{- end -}}
{{- /* One host per forge, and one GitHub host per install, as the operator's hostConflicts. */ -}}
{{- $canon := lower ($host | default "") -}}
{{- if eq $provider "github" -}}
{{- if or (not $canon) (has $canon $githubHosts) }}{{ $canon = "github.com" }}{{ end -}}
{{- if and $ghHost (ne $ghHost $canon) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host: this install's GitHub host is already %s; an install serves one GitHub host, github.com or one GitHub Enterprise Server" $i $ghHost) -}}
{{- end -}}
{{- $ghHost = $canon -}}
{{- else -}}
{{- if or (not $canon) (eq $canon "www.gitlab.com") }}{{ $canon = "gitlab.com" }}{{ end -}}
{{- end -}}
{{- if and (hasKey $hostProviders $canon) (ne (get $hostProviders $canon) $provider) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host: %s is already the host of a %s forge; one host is one forge's" $i $canon (get $hostProviders $canon)) -}}
{{- end -}}
{{- $_ := set $hostProviders $canon $provider -}}
{{- /* On every provider: the CRD's schema refuses the name wherever it is written, so the chart does too, naming the values key. */ -}}
{{- $secret := ($f.credentialsRef | default dict).name | default "" -}}
{{- if and $secret (or (gt (len $secret) 253) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" $secret))) -}}
{{- fail (printf "platformAgent.integration.forges[%d].credentialsRef.name is %q, which is not a Secret name (a lowercase DNS subdomain of at most 253 characters)" $i $secret) -}}
{{- end -}}
{{- $caMap := ($f.caBundleRef | default dict).name | default "" -}}
{{- /* A caBundleRef with no name renders nothing, so the CA would be silently missing: the CRD requires the name, and so does the chart. */ -}}
{{- if and $f.caBundleRef (not $caMap) -}}
{{- fail (printf "platformAgent.integration.forges[%d].caBundleRef needs a name: the Secret that holds the CA" $i) -}}
{{- end -}}
{{- if $caMap -}}
{{- /* gitlab.com and github.com present certificates the public CAs sign: a private CA must never vouch for them. */ -}}
{{- if or (not $host) (has (lower $host) (concat (list "gitlab.com" "www.gitlab.com") $githubHosts)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].caBundleRef is for a self-managed host; gitlab.com and github.com use the public CAs, so set host to the instance's hostname or drop caBundleRef" $i) -}}
{{- end -}}
{{- if or (gt (len $caMap) 253) (not (regexMatch "^[a-z0-9]([-a-z0-9]*[a-z0-9])?(\\.[a-z0-9]([-a-z0-9]*[a-z0-9])?)*$" $caMap)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].caBundleRef.name is %q, which is not a Secret name (a lowercase DNS subdomain of at most 253 characters)" $i $caMap) -}}
{{- end -}}
{{- $caKey := ($f.caBundleRef | default dict).key | default "" -}}
{{- if and $caKey (or (gt (len $caKey) 253) (not (regexMatch "^[-._a-zA-Z0-9]+$" $caKey)) (eq $caKey ".") (hasPrefix ".." $caKey)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].caBundleRef.key is %q, which is not a Secret key" $i $caKey) -}}
{{- end -}}
{{- /* One CA bundle for the one GitHub host, as the operator's hostConflicts: the broker trusts one bundle per host. */ -}}
{{- if eq $provider "github" -}}
{{- $thisCA := printf "%s/%s" $caMap ($caKey | default "ca.crt") -}}
{{- if and $ghCA (ne $ghCA $thisCA) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host: %s already has a CA bundle, %s; the broker trusts one CA bundle per host, so name the same Secret key on both forges or on one" $i $ghHost $ghCA) -}}
{{- end -}}
{{- $ghCA = $thisCA -}}
{{- end -}}
{{- end -}}
{{- if eq $provider "gitlab" -}}
{{- /* Any GitHub name, not only its three spellings: api.github.com or raw.githubusercontent.com would hand GitHub's traffic a GitLab token. */ -}}
{{- /* Label by label, as the operator's DNS-subdomain check: no empty or dash-edged label. */ -}}
{{- if and $host (or (not (regexMatch "^[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?(\\.[A-Za-z0-9]([A-Za-z0-9-]*[A-Za-z0-9])?)+$" $host)) (gt (len $host) 253) (regexMatch $githubReserved (lower $host))) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host is %q, which is not a hostname a gitlab forge can be at" $i $f.host) -}}
{{- end -}}
{{- if not $secret -}}
{{- fail (printf "platformAgent.integration.forges[%d] is a gitlab forge with no credentialsRef.name; name the Secret that holds its access token under the key token" $i) -}}
{{- end -}}
{{- /* One credential per host in the broker: www.gitlab.com is gitlab.com. */ -}}
{{- $glHost := lower ($host | default "gitlab.com") -}}
{{- if eq $glHost "www.gitlab.com" }}{{ $glHost = "gitlab.com" }}{{ end -}}
{{- if hasKey $gitlabHosts $glHost -}}
{{- fail (printf "platformAgent.integration.forges[%d].host: %s is already served by forges[%s]; the broker holds one credential per host, so declare one gitlab forge there" $i $glHost (get $gitlabHosts $glHost)) -}}
{{- end -}}
{{- $_ := set $gitlabHosts $glHost (toString $i) -}}
{{- end -}}
{{- $isSelfManaged := has $provider $selfManaged -}}
{{- if and $isSelfManaged (not $host) -}}
{{- fail (printf "platformAgent.integration.forges[%d].host is required: provider %s is self-managed and has no default host" $i $provider) -}}
{{- end -}}
{{- if and $f.port (not $isSelfManaged) -}}
{{- fail (printf "platformAgent.integration.forges[%d].port is set, but provider %s serves fixed endpoints" $i $provider) -}}
{{- end -}}
{{- if and $f.scheme (ne $f.scheme $defaultScheme) (not $isSelfManaged) -}}
{{- fail (printf "platformAgent.integration.forges[%d].scheme is %q, but provider %s is %s only" $i $f.scheme $provider $defaultScheme) -}}
{{- end -}}
{{- if $isSelfManaged -}}
{{- $_ := set $forgeHosts $f.name (list (lower $host)) -}}
{{- else if eq $provider "gitlab" -}}
{{- $_ := set $forgeHosts $f.name (list (lower ($host | default "gitlab.com")) "www.gitlab.com") -}}
{{- else -}}
{{- $_ := set $forgeHosts $f.name $githubHosts -}}
{{- end -}}
{{- $namespace := $f.namespace | default "" -}}
{{- if and (eq $provider "github") $namespace (not (regexMatch "^[a-zA-Z0-9]([a-zA-Z0-9-]{0,37}[a-zA-Z0-9])?$" $namespace)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].namespace is %q, which is not a GitHub organisation or user name" $i $namespace) -}}
{{- end -}}
{{- if and (eq $provider "gitlab") (gt (len $namespace) 255) -}}
{{- fail (printf "platformAgent.integration.forges[%d].namespace is longer than 255 characters" $i) -}}
{{- end -}}
{{- if and (eq $provider "gitlab") $namespace (not (regexMatch "^[A-Za-z0-9_]([A-Za-z0-9_.-]*[A-Za-z0-9_-])?(/[A-Za-z0-9_]([A-Za-z0-9_.-]*[A-Za-z0-9_-])?)*$" $namespace)) -}}
{{- fail (printf "platformAgent.integration.forges[%d].namespace is %q, which is not a GitLab group path" $i $namespace) -}}
{{- end -}}
{{- if and (eq $provider "gitlab") $namespace -}}
{{- /* As the operator: GitLab refuses a segment ending in .git or .atom, and the broker would read such a prefix with the suffix trimmed. */ -}}
{{- if regexMatch "(?i)\\.(git|atom)(/|$)" $namespace -}}
{{- fail (printf "platformAgent.integration.forges[%d].namespace is %q; a GitLab group segment may not end in .git or .atom" $i $namespace) -}}
{{- end -}}
{{- /* A first segment that is a forge host is a host, not a group: the operator refuses it, so the chart does, naming the values key. */ -}}
{{- $first := lower (first (splitList "/" $namespace)) -}}
{{- if or (has $first (list "github.com" "www.github.com" "ssh.github.com" "gitlab.com" "www.gitlab.com")) (eq $first (lower ($host | default "gitlab.com"))) -}}
{{- fail (printf "platformAgent.integration.forges[%d].namespace is %q, which starts with the forge host %q; name the group alone" $i $namespace $first) -}}
{{- end -}}
{{- end -}}
{{- $names = append $names $f.name -}}
{{- $providers = append $providers $provider -}}
{{- $_ := set $namespaces $f.name $namespace -}}
{{- end -}}
{{- $gitops := dict -}}
{{- range $i, $r := $repos -}}
{{- if eq ($r.role | default "") "gitops" -}}
{{- if hasKey $gitops "index" -}}
{{- fail (printf "platformAgent.integration.repositories[%d].role is gitops, but repositories[%d] already is; at most one repository may have role gitops" $i (get $gitops "index")) -}}
{{- end -}}
{{- $_ := set $gitops "index" $i -}}
{{- end -}}
{{- if not (has $r.forge $names) -}}
{{- fail (printf "platformAgent.integration.repositories[%d].forge is %q, which is not a name in platformAgent.integration.forges" $i ($r.forge | default "")) -}}
{{- end -}}
{{- $repository := $r.repository | default "" -}}
{{- if not $repository -}}
{{- fail (printf "platformAgent.integration.repositories[%d].repository is required" $i) -}}
{{- end -}}
{{- if eq $repository "None" -}}
{{- fail (printf "platformAgent.integration.repositories[%d].repository is \"None\", the deprecated github.gitRepo's \"no repository\" value; omit the entry instead" $i) -}}
{{- end -}}
{{- /* Bare as the operator reads it: surrounding slashes and one `.git` dropped first, so `infra/` is bare too. */ -}}
{{- $trimmed := trimAll "/" $repository -}}
{{- $name := trimSuffix ".git" $trimmed -}}
{{- if and $name (not (hasSuffix "/" $name)) -}}
{{- $trimmed = trimAll "/" $name -}}
{{- end -}}
{{- /* A forge's own host followed only by `/` names no repository, which a namespace would not fix; the operator refuses it against this entry. */ -}}
{{- $hostOnly := and (hasSuffix "/" $repository) (regexMatch "^[A-Za-z0-9./-]+$" $repository) (has (lower (trimAll "/" $repository)) (get $forgeHosts $r.forge)) -}}
{{- if and (not (contains "/" $trimmed)) (not (contains ":" $repository)) (not $hostOnly) (not $r.namespace) (not (get $namespaces $r.forge)) -}}
{{- fail (printf "platformAgent.integration.repositories[%d].repository is %q, a bare name, but neither the entry nor forge %q declares a namespace to qualify it" $i $repository $r.forge) -}}
{{- end -}}
{{- end -}}
{{- if $githubSet -}}
{{- $providers = list "github" -}}
{{- end -}}
{{- join "," (uniq $providers) -}}
{{- end }}

{{/*
Admission-webhook object names, mirroring k8s-operator/config/webhook and
config/certmanager.

Defined here rather than inlined because four templates have to agree on them:
the Service the webhook configurations' clientConfig points at, the Certificate
whose dnsNames must match that Service, the Secret the Deployment mounts, and
the inject-ca-from annotation. A name that disagrees across any two of those
renders valid YAML and fails at admission time, which is the wrong place to find
out.

The webhook configurations are cluster-scoped, so they carry the namespace
component the chart already uses for the operator ClusterRole — two releases in
different namespaces would otherwise fight over one object, and the loser's
clientConfig would point every PlatformAgent admission in the cluster at the
wrong Service.
*/}}
{{- define "kube-agents.webhookServiceName" -}}
{{ .Release.Name }}-webhook-service
{{- end }}

{{- define "kube-agents.webhookCertificateName" -}}
{{ .Release.Name }}-serving-cert
{{- end }}

{{- define "kube-agents.webhookCertSecretName" -}}
{{ .Release.Name }}-webhook-certs
{{- end }}

{{- define "kube-agents.webhookConfigurationPrefix" -}}
{{ .Release.Name }}-{{ .Release.Namespace }}
{{- end }}

{{/*
Validates and resolves a Deployment's rollingUpdate fenceposts, returning a
YAML map with `maxSurge` and `maxUnavailable`. Callers parse the output with
`| fromYaml`.

Both fenceposts at zero leaves the Deployment no way to make progress and
the API server rejects it ("may not be 0 when maxSurge is 0"), so fail
the render rather than the apply. See values.yaml's rollingUpdate blocks.

A fencepost with no usable value takes the given default (defaultSurge,
defaultUnavailable) and renders explicitly. "No usable value" has to mean
the empty string as well as nil/invalid: `--set <scope>.maxUnavailable=` and
a values file's `maxUnavailable: ""` both reach here as an empty string,
which is a perfectly good `kind` and so survives a nil test. Rendering
either through would emit `maxUnavailable:` with nothing after it, and
Kubernetes then applies its own 25% default.

Both fields are IntOrString, which is what makes the zero test awkward:
`int` is cast.ToInt and reads "25%" as 0, so it would refuse a pair of
perfectly good percentages, while a list of literal spellings misses
"0.0". Compare numerically with the percent sign stripped — "0%"
resolves to 0 on the cluster, so it is the same misconfiguration spelled
differently. `float64` is cast.ToFloat64, which reports anything it
cannot parse as 0, so the numeric test is gated on both values actually
being numeric: without that, `maxSurge: abc` is refused as a zero and
the message names the wrong problem. Non-numeric input is left to the
API server, which is where it was rejected before this guard existed.

Takes a dict: {rollingUpdate, defaultSurge, defaultUnavailable, scope}.
*/}}
{{- define "kube-agents.rollingUpdateFenceposts" -}}
{{- $ru := .rollingUpdate | default dict -}}
{{- $surge := $ru.maxSurge -}}
{{- $unavail := $ru.maxUnavailable -}}
{{- $defaultSurge := .defaultSurge -}}
{{- if kindIs "invalid" $defaultSurge }}{{- $defaultSurge = 1 }}{{- end -}}
{{- $defaultUnavail := .defaultUnavailable -}}
{{- if kindIs "invalid" $defaultUnavail }}{{- $defaultUnavail = 0 }}{{- end -}}
{{- if or (kindIs "invalid" $surge) (eq (toString $surge) "") }}{{- $surge = $defaultSurge }}{{- end -}}
{{- if or (kindIs "invalid" $unavail) (eq (toString $unavail) "") }}{{- $unavail = $defaultUnavail }}{{- end -}}
{{- $surgeNum := trimSuffix "%" (trim (toString $surge)) -}}
{{- $unavailNum := trimSuffix "%" (trim (toString $unavail)) -}}
{{- $numeric := "^[0-9]+(\\.[0-9]+)?$" -}}
{{- if and (regexMatch $numeric $surgeNum) (regexMatch $numeric $unavailNum) -}}
{{- if and (eq (float64 $surgeNum) 0.0) (eq (float64 $unavailNum) 0.0) -}}
{{- fail (printf "%s: maxSurge (%v) and maxUnavailable (%v) may not both be zero — the Deployment would have no way to make progress, and the API server rejects it." .scope $surge $unavail) -}}
{{- end -}}
{{- end -}}
maxSurge: {{ $surge }}
maxUnavailable: {{ $unavail }}
{{- end }}

{{/*
Resource parsing helpers for quota preflight (#749).
Converts Kubernetes quantities to canonical integer units:
- CPU: millicores (e.g. "500m" -> 500, "1" -> 1000, "1.5" -> 1500, "1500u" -> 2)
- Memory / Storage: bytes (e.g. "128Mi" -> 134217728, "2Gi" -> 2147483648)

Both fail the render on a quantity they cannot parse rather than returning a number.
An earlier version fell through to `int64`, which yields 0 for anything it does not
understand: a `1Pi` quota then read as `hard 0` and the release was refused with a
message describing a cluster that does not exist. A quantity this cannot read is a bug
in this helper, and saying so is the only honest outcome.

Every conversion to an integer goes through kube-agents.clampInt64 rather than `int64`,
because the millicore and byte forms of a large quantity overflow where the quantity
itself does not. `1E` CPU is 10^21 millicores and `8Ei` is 2^63 bytes, both past
math.MaxInt64, and Go's float-to-int conversion wraps them to -9223372036854775808:
`hard` then read as negative, fell short of every requirement it dwarfs, and the render
was refused with a patch asking for a negative quota. Saturating keeps the comparison
honest — a quota that large cannot constrain this release either way.
*/}}
{{- /* Float to int64, saturating rather than wrapping. 2^63 is the first float64 above
       math.MaxInt64, which is not itself representable as a float64 — comparing against
       a rounded MaxInt64 would let the wrapping value through. */ -}}
{{- define "kube-agents.clampInt64" -}}
{{- $v := float64 . -}}
{{- if ge $v 9223372036854775808.0 -}}
9223372036854775807
{{- else -}}
{{- $v | int64 -}}
{{- end -}}
{{- end }}

{{- /* Saturating int64 add and multiply for the quota sums. Sprig's add and mul are
       plain int64 and wrap. A sidecar or proxy resource limit the validator admits
       (any byte count under 2^63; bytesExceedInt64 refuses the rest) can still carry
       the agent-pod sum or the replica multiply past int64, wrapping a `required`
       figure negative so the quota check passes every quota -- the exact failure the
       preflight exists to prevent. These compute in float64 and clamp with clampInt64,
       so an over-large figure makes `required` read as the MaxInt64 ceiling, which no
       real quota satisfies, rather than negative. float64 loses integer precision above
       2^53, which only shifts a figure already far larger than any quota, where the
       ceiling is the intended answer. Take (dict "a" <int64> "b" <int64>). */ -}}
{{- define "kube-agents.satAdd" -}}
{{- include "kube-agents.clampInt64" (addf (float64 .a) (float64 .b)) -}}
{{- end }}
{{- define "kube-agents.satMul" -}}
{{- include "kube-agents.clampInt64" (mulf (float64 .a) (float64 .b)) -}}
{{- end }}

{{- define "kube-agents.parseCpuMillis" -}}
{{- $raw := include "kube-agents.normalizeQuantity" . -}}
{{- $numeric := "^[0-9]+(\\.[0-9]+)?([eE][-+]?[0-9]+)?$" -}}
{{- $binaryCores := dict "Ki" 1024.0 "Mi" 1048576.0 "Gi" 1073741824.0 "Ti" 1099511627776.0 "Pi" 1125899906842624.0 "Ei" 1152921504606846976.0 -}}
{{- $decimalCores := dict "k" 1000.0 "M" 1000000.0 "G" 1000000000.0 "T" 1000000000000.0 "P" 1000000000000000.0 "E" 1000000000000000000.0 -}}
{{- if or (eq $raw "") (eq $raw "<nil>") -}}
0
{{- else if hasSuffix "m" $raw -}}
{{- $n := trimSuffix "m" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (float64 $n)) -}}
{{- else if hasSuffix "u" $raw -}}
{{- $n := trimSuffix "u" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (divf (float64 $n) 1000.0)) -}}
{{- else if hasSuffix "n" $raw -}}
{{- $n := trimSuffix "n" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (divf (float64 $n) 1000000.0)) -}}
{{- else -}}
{{- $out := "" -}}
{{- range $unit, $mult := $binaryCores -}}
{{- if and (eq $out "") (hasSuffix $unit $raw) -}}
{{- $n := trimSuffix $unit $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (mulf (mulf (float64 $n) $mult) 1000.0) -}}
{{- end -}}
{{- end -}}
{{- range $unit, $mult := $decimalCores -}}
{{- if and (eq $out "") (hasSuffix $unit $raw) -}}
{{- $n := trimSuffix $unit $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (mulf (mulf (float64 $n) $mult) 1000.0) -}}
{{- end -}}
{{- end -}}
{{- if eq $out "" -}}
{{- if not (regexMatch $numeric $raw) -}}
{{- fail (printf "quota preflight: cannot parse CPU quantity %q — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (mulf (float64 $raw) 1000.0) -}}
{{- end -}}
{{- $out -}}
{{- end -}}
{{- end }}

{{- /* A quantity in the CRD's grammar rewritten into the one parseCpuMillis and
       parseBytes read, which both call it first: trimmed, the leading "+" dropped,
       `.5` written `0.5`, and `1.` written `1`. A "-" is left in place, so a negative
       still fails the parse. */ -}}
{{- define "kube-agents.normalizeQuantity" -}}
{{- $raw := trimPrefix "+" (trim (toString .)) -}}
{{- if hasPrefix "." $raw -}}
{{- $raw = printf "0%s" $raw -}}
{{- end -}}
{{- regexReplaceAll "^([0-9]+)\\.([^0-9]|$)" $raw "${1}${2}" -}}
{{- end }}

{{- define "kube-agents.parseBytes" -}}
{{- $raw := include "kube-agents.normalizeQuantity" . -}}
{{- $numeric := "^[0-9]+(\\.[0-9]+)?([eE][-+]?[0-9]+)?$" -}}
{{- $binary := dict "Ki" 1024.0 "Mi" 1048576.0 "Gi" 1073741824.0 "Ti" 1099511627776.0 "Pi" 1125899906842624.0 "Ei" 1152921504606846976.0 -}}
{{- $decimal := dict "k" 1000.0 "M" 1000000.0 "G" 1000000000.0 "T" 1000000000000.0 "P" 1000000000000000.0 "E" 1000000000000000000.0 -}}
{{- if or (eq $raw "") (eq $raw "<nil>") -}}
0
{{- else if hasSuffix "m" $raw -}}
{{- $n := trimSuffix "m" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (divf (float64 $n) 1000.0)) -}}
{{- else if hasSuffix "u" $raw -}}
{{- $n := trimSuffix "u" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (divf (float64 $n) 1000000.0)) -}}
{{- else if hasSuffix "n" $raw -}}
{{- $n := trimSuffix "n" $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- include "kube-agents.clampInt64" (ceil (divf (float64 $n) 1000000000.0)) -}}
{{- else -}}
{{- $out := "" -}}
{{- range $unit, $mult := $binary -}}
{{- if and (eq $out "") (hasSuffix $unit $raw) -}}
{{- $n := trimSuffix $unit $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (mulf (float64 $n) $mult) -}}
{{- end -}}
{{- end -}}
{{- if eq $out "" -}}
{{- range $unit, $mult := $decimal -}}
{{- if and (eq $out "") (hasSuffix $unit $raw) -}}
{{- $n := trimSuffix $unit $raw -}}
{{- if not (regexMatch $numeric $n) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (mulf (float64 $n) $mult) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- if eq $out "" -}}
{{- if not (regexMatch $numeric $raw) -}}
{{- fail (printf "quota preflight: cannot parse quantity %q (memory, storage or count) — set quotaPreflight.enabled=false to bypass, and please report it." $raw) -}}
{{- end -}}
{{- $out = include "kube-agents.clampInt64" (float64 $raw) -}}
{{- end -}}
{{- $out -}}
{{- end -}}
{{- end }}

{{- /* "true" when a byte quantity's value is at or past 2^63, which parseBytes saturates
       to math.MaxInt64 and the operator refuses as unrepresentable. The quota sums want
       the saturation; the credential-proxy render check wants the refusal, so it asks
       this first. The arithmetic is parseBytes', so a value float64 rounds up to 2^63
       from just below it (within 1024 of it) is refused too. Reads only what
       parseBytes reads; call it after the quantity has passed the CRD's grammar. */ -}}
{{- define "kube-agents.bytesExceedInt64" -}}
{{- $raw := include "kube-agents.normalizeQuantity" . -}}
{{- $scaled := dict "Ki" 1024.0 "Mi" 1048576.0 "Gi" 1073741824.0 "Ti" 1099511627776.0 "Pi" 1125899906842624.0 "Ei" 1152921504606846976.0 "k" 1000.0 "M" 1000000.0 "G" 1000000000.0 "T" 1000000000000.0 "P" 1000000000000000.0 "E" 1000000000000000000.0 -}}
{{- $divided := dict "m" 1000.0 "u" 1000000.0 "n" 1000000000.0 -}}
{{- $v := "" -}}
{{- range $unit, $mult := $scaled -}}
{{- if and (kindIs "string" $v) (hasSuffix $unit $raw) -}}
{{- $v = mulf (float64 (trimSuffix $unit $raw)) $mult -}}
{{- end -}}
{{- end -}}
{{- range $unit, $div := $divided -}}
{{- if and (kindIs "string" $v) (hasSuffix $unit $raw) -}}
{{- $v = divf (float64 (trimSuffix $unit $raw)) $div -}}
{{- end -}}
{{- end -}}
{{- if kindIs "string" $v -}}
{{- $v = float64 $raw -}}
{{- end -}}
{{- if ge (float64 $v) 9223372036854775808.0 -}}true{{- end -}}
{{- end }}

{{- /* "true" when a quantity's number is past float64's range. Sprig's float64 answers 0
       for it rather than failing (strconv reports +Inf with ErrRange, and the cast drops
       both), so `1e400` would read as zero and pass every check after it. The number
       reads as 0 for one other reason, an underflow (1e-400), which is a real positive
       quantity the operator rounds up rather than refuses; the two are told apart by the
       number's order of magnitude: its integer digits, or minus the zeros leading its
       fraction, plus its exponent. Call it after the quantity has passed the CRD's
       grammar. */ -}}
{{- define "kube-agents.quantityOverflowsFloat64" -}}
{{- $num := regexReplaceAll "([KMGTPE]i|[numkMGTPE])$" (include "kube-agents.normalizeQuantity" .) "" -}}
{{- $mantissa := regexReplaceAll "[eE].*$" $num "" -}}
{{- if and (regexMatch "[1-9]" $mantissa) (eq (float64 $num) 0.0) -}}
{{- $intDigits := regexReplaceAll "^0+" (regexReplaceAll "\\..*$" $mantissa "") "" -}}
{{- $magnitude := len $intDigits -}}
{{- if eq $magnitude 0 -}}
{{- $fraction := regexReplaceAll "^[^.]*\\.?" $mantissa "" -}}
{{- $magnitude = sub (len (regexReplaceAll "^0+" $fraction "")) (len $fraction) -}}
{{- end -}}
{{- $exponent := regexReplaceAll "^[^eE]*[eE]?" $num "" -}}
{{- $negative := hasPrefix "-" $exponent -}}
{{- $digits := regexReplaceAll "^0+" (trimPrefix "+" (trimPrefix "-" $exponent)) "" -}}
{{- /* An exponent past 18 digits does not fit the int64 below, and decides alone. */ -}}
{{- if gt (len $digits) 18 -}}
{{- if not $negative -}}true{{- end -}}
{{- else -}}
{{- $e := $digits | default "0" | int64 -}}
{{- if $negative -}}
{{- $e = sub 0 $e -}}
{{- end -}}
{{- if gt (add $magnitude $e) 0 -}}true{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- /* A quantity's value as a float64, in millicores when "cpu" is true and bytes otherwise,
       with no rounding of its own: parseCpuMillis and parseBytes truncate a bare or
       suffixed value and ceil an m, u or n one, which suits the quota sums and would let
       the credential-proxy crossed-pair check disagree with the operator's exact
       resource.Quantity comparison (1.0004 against 1 would compare equal). Sprig's mulf
       and divf compute in decimal and round once to float64, so a decimal quantity of at
       most 15 significant digits (credentialProxyResourcesCheck refuses more) scales
       exactly: 1.005 cores and 1005m both read as 1005 millicores, and a strict lt or gt
       on two figures matches the operator's Quantity.Cmp for every decimal value the
       chart admits that is a whole number of nano-units. Two residues remain. A binary-suffixed quantity (Ki to Ei) multiplies
       the digits by a power of two and can land within float64 rounding, about one part
       in 10^16, of a decimal one: 976562500000459Ki is 16 bytes above 100000000000047e4,
       yet both read as the same float64, so the chart admits that crossed pair and the
       operator decides. And the operator rounds a quantity up to whole nano-units, which
       the chart does not, so two values that differ only below a nano-unit (1.5n against
       1.2n) can compare differently here than there. A value whose scaled figure is past
       float64's range (a CPU of 1e308, in millicores) fails the render naming "key"
       rather than answering "", which a caller would read as zero.
       Takes (dict "raw" <quantity> "cpu" <bool> "key" <values path>); call it after the
       quantity has passed the CRD's grammar. */ -}}
{{- define "kube-agents.quantityExact" -}}
{{- $raw := include "kube-agents.normalizeQuantity" .raw -}}
{{- $scale := ternary 1000.0 1.0 (eq .cpu true) -}}
{{- $scaled := dict "Ki" 1024.0 "Mi" 1048576.0 "Gi" 1073741824.0 "Ti" 1099511627776.0 "Pi" 1125899906842624.0 "Ei" 1152921504606846976.0 "k" 1000.0 "M" 1000000.0 "G" 1000000000.0 "T" 1000000000000.0 "P" 1000000000000000.0 "E" 1000000000000000000.0 -}}
{{- $divided := dict "m" 1000.0 "u" 1000000.0 "n" 1000000000.0 -}}
{{- $v := "" -}}
{{- range $unit, $mult := $scaled -}}
{{- if and (kindIs "string" $v) (hasSuffix $unit $raw) -}}
{{- $v = mulf (float64 (trimSuffix $unit $raw)) $mult $scale -}}
{{- end -}}
{{- end -}}
{{- range $unit, $div := $divided -}}
{{- if and (kindIs "string" $v) (hasSuffix $unit $raw) -}}
{{- $v = divf (mulf (float64 (trimSuffix $unit $raw)) $scale) $div -}}
{{- end -}}
{{- end -}}
{{- if kindIs "string" $v -}}
{{- $v = mulf (float64 $raw) $scale -}}
{{- end -}}
{{- /* +Inf is the only float64 greater than the largest finite one. */ -}}
{{- if gt (float64 $v) 1.7976931348623157e308 -}}
{{- fail (printf "%s is %s, which is not a representable quantity: its value with the suffix applied is past the range of a float64, which the chart would read as zero and so could not check against the operator's rules" .key $raw) -}}
{{- end -}}
{{- $v | toJson -}}
{{- end }}

{{/*
Count quotas (`pods`, `persistentvolumeclaims`) go through the same parser.

They are not plain integers on the wire. The API server round-trips every quota value
through resource.Quantity and writes back the canonical form, so a namespace created
with `pods: 1000` is read back as `pods: "1k"`. Sprig's `int64` is `cast.ToInt64`, which
answers 0 for a string it cannot parse rather than failing — so an earlier version read
that quota as `hard 0`, refused the release for a shortfall that did not exist, and
printed a patch lowering the namespace to 7 pods for whoever followed the instructions.
parseBytes already reads the decimal-SI suffixes this needs, and fails loudly on the rest.
*/}}
{{- define "kube-agents.parseCount" -}}
{{- include "kube-agents.parseBytes" . -}}
{{- end }}

{{/*
Format helpers for friendly error display and patch generation:
- CPU: converts millicores to e.g. "10000m" (or "10" if exact integer cores)
- Memory / Storage: converts bytes to Mi / Gi
scripts/generate_chart_footprint.py has the same two functions, so the numbers the
preflight prints and the numbers in footprint.yaml are written the same way.
*/}}
{{- define "kube-agents.formatCpu" -}}
{{- $m := int64 . -}}
{{- if and (gt $m 0) (eq (mod $m 1000) 0) -}}
{{- printf "%d" (div $m 1000) -}}
{{- else -}}
{{- printf "%dm" $m -}}
{{- end -}}
{{- end }}

{{- define "kube-agents.formatBytes" -}}
{{- $b := int64 . -}}
{{- if and (gt $b 0) (eq (mod $b 1073741824) 0) -}}
{{- printf "%dGi" (div $b 1073741824) -}}
{{- else if and (gt $b 0) (eq (mod $b 1048576) 0) -}}
{{- printf "%dMi" (div $b 1048576) -}}
{{- else -}}
{{- printf "%d" $b -}}
{{- end -}}
{{- end }}

{{/*
Two more byte formatters, for the quota diagnosis rather than for footprint.yaml.

formatBytes above only names a unit when the value divides exactly, and falls back to a
bare byte count otherwise. That is right for footprint.yaml, whose numbers are always
Mi-aligned, and wrong in the failure message: a namespace whose quota is written in
decimal SI (`requests.memory: 10G`) turns every figure into an eleven-digit byte count,
which is the opposite of the legible diagnosis this check exists to give.

Rounding in a patch value is not free, so the direction is chosen per use:

- formatBytesCeil rounds UP to whole Mi, and sizes the remediation patch. Rounding down
  would print a patch that is short of what the release needs, which is worse than an
  ugly number: the operator runs it and the install still fails.
- formatBytesApprox rounds toward zero and marks the result `~`, and is display-only.
  Nothing is computed from it, and the `~` keeps it from being read as exact.
*/}}
{{- define "kube-agents.formatBytesCeil" -}}
{{- $b := int64 . -}}
{{- if and (gt $b 0) (eq (mod $b 1048576) 0) -}}
{{- include "kube-agents.formatBytes" $b -}}
{{- else if le $b 0 -}}
{{- printf "%d" $b -}}
{{- else -}}
{{- printf "%dMi" (div (add $b 1048575) 1048576) -}}
{{- end -}}
{{- end }}

{{- define "kube-agents.formatBytesApprox" -}}
{{- $b := int64 . -}}
{{- if and (gt $b 0) (eq (mod $b 1048576) 0) -}}
{{- include "kube-agents.formatBytes" $b -}}
{{- else if eq $b 0 -}}
0
{{- else -}}
{{- printf "~%dMi" (div $b 1048576) -}}
{{- end -}}
{{- end }}

{{/*
Reads one resources block — requests and limits, CPU, memory and ephemeral-storage — from a
values subtree, and returns the parsed quantities as JSON.

Every field is optional at every level. values.schema.json declares each `resources` as a
bare object with no `required` keyword, so `--set litellm.resources.limits=null` — the
documented Helm way to drop a key, and the obvious edit for someone who does not want
limits charged against a quota — is valid input. Reaching through it with
`.Values.litellm.resources.limits.cpu` aborted the whole render with `nil pointer
evaluating interface {}.cpu`, and only in a namespace that has a ResourceQuota, which is
the one population this check exists for.

When requests are omitted but limits are specified, Kubernetes defaults the request to
match the limit at admission time, which is reflected here. When a quantity is omitted
from both requests and limits, it contributes zero to the sum (though note that if a
ResourceQuota constrains that resource, Kubernetes quota admission requires containers
to declare it unless defaulted by a LimitRange).

"Omitted" is decided by kube-agents.declaredQuantity rather than by Sprig's `default`,
for the same reason kube-agents.replicaCount exists: `default` calls 0 empty, and each
`resources` block is an open object in values.schema.json, so `requests: {cpu: 0}` is
valid input that arrives as a numeric zero. Chained through `default` it read as absent
and was charged the limit instead — a workload asking for nothing was summed as the
largest thing it could ever use.
*/}}
{{- define "kube-agents.declaredQuantity" -}}
{{- $v := .value -}}
{{- if or (kindIs "invalid" $v) (eq (toString $v) "") -}}
{{- toString .fallback -}}
{{- else -}}
{{- toString $v -}}
{{- end -}}
{{- end }}

{{- define "kube-agents.workloadResources" -}}
{{- $res := (. | default dict).resources | default dict -}}
{{- $req := (index $res "requests") | default dict -}}
{{- $lim := (index $res "limits") | default dict -}}
{{- $cpuLim := include "kube-agents.declaredQuantity" (dict "value" (index $lim "cpu") "fallback" "0") -}}
{{- $memLim := include "kube-agents.declaredQuantity" (dict "value" (index $lim "memory") "fallback" "0") -}}
{{- $ephLim := include "kube-agents.declaredQuantity" (dict "value" (index $lim "ephemeral-storage") "fallback" "0") -}}
{{- $cpuReq := include "kube-agents.declaredQuantity" (dict "value" (index $req "cpu") "fallback" $cpuLim) -}}
{{- $memReq := include "kube-agents.declaredQuantity" (dict "value" (index $req "memory") "fallback" $memLim) -}}
{{- $ephReq := include "kube-agents.declaredQuantity" (dict "value" (index $req "ephemeral-storage") "fallback" $ephLim) -}}
{{- dict
      "cpuRequest" (include "kube-agents.parseCpuMillis" $cpuReq | int64)
      "cpuLimit" (include "kube-agents.parseCpuMillis" $cpuLim | int64)
      "memoryRequest" (include "kube-agents.parseBytes" $memReq | int64)
      "memoryLimit" (include "kube-agents.parseBytes" $memLim | int64)
      "ephemeralRequest" (include "kube-agents.parseBytes" $ephReq | int64)
      "ephemeralLimit" (include "kube-agents.parseBytes" $ephLim | int64)
   | toJson -}}
{{- end }}

{{/*
Replica count, where an explicit 0 means 0.

`replicas | default 1` reads a falsy 0 as absent and charges a full replica for a workload
scaled to zero. AvailabilitySpec.Replicas is +kubebuilder:validation:Minimum=0
(k8s-operator/api/v1alpha1/common_types.go), so 0 is a value a user can legitimately set,
and the chart's own replicaCount keys take one too. Only an absent value defaults to 1.
*/}}
{{- define "kube-agents.replicaCount" -}}
{{- if kindIs "invalid" . -}}
1
{{- else -}}
{{- int64 . -}}
{{- end -}}
{{- end }}

{{/*
Preflight validation against namespace ResourceQuotas (#749).

Split into three templates so the parts that need no cluster can be tested without one:

- kube-agents.quotaRequirements — totals what the release needs, as JSON. Pure function of
  the values and footprint.yaml.
- kube-agents.quotaCheckItems — compares those totals against a list of ResourceQuota
  objects and fails the render on a shortfall. Takes the list as an argument.
- kube-agents.quotaPreflight — the entry point: looks the quotas up, then calls the two above.

Only the last one touches the cluster, so tests/test_quota_preflight.py can drive the other
two with synthetic quotas and assert the arithmetic and the pass/fail decision offline.

Fails the render if:
- hard < required (the quota cannot fit the release even if empty)
- OR (hard - used) < required AND .Release.IsInstall (on a fresh install, remaining headroom
  is insufficient). Install-only on purpose: on upgrade the release's own pods are already
  counted in `used`, so subtracting them again would refuse every upgrade of a release that
  exactly fits its quota. The cost of that exemption is that `used` on upgrade also holds
  any neighbouring workload's usage, which this cannot tell apart from the release's own —
  so in a namespace shared with other workloads an upgrade is checked against `hard` alone.

Quota keys understood: CPU, memory and ephemeral-storage (requests and limits), pods,
persistentvolumeclaims and requests.storage. Keys outside that set (services, secrets, other
count/<resource>) are not modelled, and are skipped rather than guessed at.

Inert when lookup returns empty — `helm template` without a cluster, or a namespace with no
ResourceQuota at all.

It is NOT inert when the installing identity cannot read ResourceQuotas. Helm's `lookup`
swallows a NotFound and returns nothing; every other API error, a 403 on
`list resourcequotas` among them, comes back as a template error and aborts the render. So
the check needs `get`/`list` on `resourcequotas` in the release namespace, and an identity
without it installs with `--set quotaPreflight.enabled=false`. Nothing here can soften that:
a Go template cannot catch the error `lookup` raises.
*/}}
{{/*
The checks on platformAgent.deployment.credentialProxy.resources that need no parsed value:
the keys under resources, the shape of limits and requests, each resource name, and each
quantity's sign, grammar, significant digits (at most 15, the most float64 holds exactly, so
the comparisons after these match the operator's for every decimal value admitted) and range: a byte count
within an int64, a CPU within an int64 of millicores. Takes the resources map and renders
nothing; a value that fails one fails the render naming its key. Both readers of the value call it first,
the CR template (templates/platform-agent-cr.yaml) and kube-agents.credentialProxyFootprint
for the quota preflight, because Helm renders quota-preflight.yaml before the CR template:
without it the preflight's parseBytes refused `-1Gi` or `2GB` with a "cannot parse ...
please report it" message before the CR template could name the key. The checks that
compare parsed values (zero limit, floor, crossed pair) stay in the CR template, after
these have passed.
*/}}
{{- /* Shape, grammar and representability check for a container's resources override,
       shared by the credential proxy and the agent-api-auth sidecar. Both the quota
       preflight and the CR template call it, so a mistyped side key, an unsupported
       claims, a non-map side, an unknown resource name or a quantity the preflight
       arithmetic cannot represent (a value float64 reads as zero, a byte count over an
       int64, a CPU past the millicore range) fails the render naming the key, rather
       than being pruned silently or reaching the footprint math as garbage. Caller
       passes resources, prefix, container, pod and consumer (the Downward API reader). */ -}}
{{- define "kube-agents.containerResourcesCheck" -}}
{{- $resources := .resources | default dict -}}
{{- $prefix := .prefix -}}
{{- $container := .container -}}
{{- $pod := .pod -}}
{{- $consumer := .consumer -}}
{{- $unknown := keys (omit $resources "limits" "requests" "claims") | sortAlpha -}}
{{- if $unknown -}}
{{- fail (printf "%s carries %s, which the PlatformAgent CRD does not declare; the accepted keys are requests, limits and claims. The API server would prune it, and the override would be lost silently" $prefix (join ", " $unknown)) -}}
{{- end -}}
{{- if index $resources "claims" -}}
{{- fail (printf "%s.claims is not supported -- the %s declares no resourceClaims, so the operator refuses the key. Remove it." $prefix $pod) -}}
{{- end -}}
{{- $names := list "cpu" "memory" "ephemeral-storage" -}}
{{- /* The CRD's quantity grammar, the sign already stripped, with the
       exponent narrowed to the integer form resource.ParseQuantity reads.
       parseCpuMillis and parseBytes read every form this admits. */ -}}
{{- $quantityPattern := "^(([0-9]+(\\.[0-9]*)?)|(\\.[0-9]+))(([KMGTPE]i)|[numkMGTPE]|([eE][-+]?[0-9]+))?$" -}}
{{- range $side := list "limits" "requests" -}}
{{- $quantities := index $resources $side -}}
{{- /* `--set ...limits=2Gi` hands range a string, which it cannot walk, and a list
       gives it integer names; either is a shape the CRD refuses. */ -}}
{{- if not (or (empty $quantities) (kindIs "map" $quantities)) -}}
{{- fail (printf "%s.%s is %v, which is not a map of resource name to quantity, for example `limits: {memory: 2Gi}`" $prefix $side $quantities) -}}
{{- end -}}
{{- range $name, $quantity := $quantities | default dict -}}
{{- if not (or (kindIs "invalid" $quantity) (and (kindIs "string" $quantity) (eq $quantity ""))) -}}
{{- $raw := toString $quantity | trim -}}
{{- if not (has $name $names) -}}
{{- fail (printf "%s.%s.%s: the %s container declares cpu, memory and ephemeral-storage only, and the operator refuses any other resource name" $prefix $side $name $container) -}}
{{- end -}}
{{- if hasPrefix "-" $raw -}}
{{- fail (printf "%s.%s.%s is %s; a quantity must not be negative, and the operator refuses it" $prefix $side $name $raw) -}}
{{- end -}}
{{- if not (regexMatch $quantityPattern (trimPrefix "+" $raw)) -}}
{{- fail (printf "%s.%s.%s is %q, which is not a Kubernetes quantity the operator can read (a number with an optional suffix: Ki, Mi, Gi, Ti, Pi, Ei, n, u, m, k, M, G, T, P, E, or an integer exponent such as e3)" $prefix $side $name $raw) -}}
{{- end -}}
{{- /* float64 holds 15 significant decimal digits exactly; a 16th lets two quantities
       within one part in 10^16 of each other, or of a bound, read as equal, and the
       render would pass what the operator's exact comparison refuses. Counted on the
       mantissa: sign, exponent, suffix and dot stripped, then leading and trailing
       zeros. */ -}}
{{- $significand := regexReplaceAll "([KMGTPE]i|[numkMGTPE])$" (regexReplaceAll "[eE][-+]?[0-9]+$" (trimPrefix "+" $raw) "") "" -}}
{{- $significand = regexReplaceAll "0+$" (regexReplaceAll "^0+" (replace "." "" $significand) "") "" -}}
{{- if gt (len $significand) 15 -}}
{{- fail (printf "%s.%s.%s is %s, which has more than 15 significant digits: the chart compares quantities as float64, which holds 15 exactly, so it cannot check this one against the operator's rules. Write it with a larger unit or fewer digits" $prefix $side $name $raw) -}}
{{- end -}}
{{- if include "kube-agents.quantityOverflowsFloat64" $raw -}}
{{- if eq $name "cpu" -}}
{{- fail (printf "%s.%s.%s is %s, which is not a representable quantity: it is past the range of a float64, which the chart would read as zero, and its millicore value exceeds the 9223372036854775807 an int64 holds, so the operator refuses it" $prefix $side $name $raw) -}}
{{- else -}}
{{- fail (printf "%s.%s.%s is %s, which is not a representable byte count: it exceeds the 9223372036854775807 bytes an int64 holds, which is what the Downward API hands the %s, and the operator refuses it" $prefix $side $name $raw $consumer) -}}
{{- end -}}
{{- end -}}
{{- if and (ne $name "cpu") (include "kube-agents.bytesExceedInt64" $raw) -}}
{{- fail (printf "%s.%s.%s is %s, which is not a representable byte count: it exceeds the 9223372036854775807 bytes an int64 holds, which is what the Downward API hands the %s, and the operator refuses it" $prefix $side $name $raw $consumer) -}}
{{- end -}}
{{- /* The operator reads a CPU quantity in millicores (MilliValue), which wraps past
       2^63; it refuses one there, so the render does too. A suffix that carries a
       finite number past float64's range (a 1 and 306 zeros, then k) fails inside
       quantityExact, naming the key. */ -}}
{{- if eq $name "cpu" -}}
{{- $cores := include "kube-agents.quantityExact" (dict "raw" $raw "cpu" false "key" (printf "%s.%s.%s" $prefix $side $name)) | float64 -}}
{{- if ge (mulf $cores 1000.0) 9223372036854775808.0 -}}
{{- fail (printf "%s.%s.%s is %s, which is not a CPU count the scheduler can represent in millicores: its millicore value exceeds the 9223372036854775807 an int64 holds, and the operator refuses it" $prefix $side $name $raw) -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "kube-agents.credentialProxyResourcesCheck" -}}
{{- include "kube-agents.containerResourcesCheck" (dict "resources" . "prefix" "platformAgent.deployment.credentialProxy.resources" "container" "credential-proxy" "pod" "credential-proxy pod" "consumer" "broker") -}}
{{- end }}

{{/*
The credential proxy's footprint entry with platformAgent.deployment.credentialProxy.resources
merged over it, per key, as resolveCredentialProxyResources does in the operator
(k8s-operator/internal/controller/credential_proxy_manifests.go): a key the override
carries replaces that number, a key it omits keeps footprint.yaml's -- with one exception
that follows the API server rather than the operator. The operator renders a CPU and a
memory request explicitly, so an override that raises only the limit leaves the request where
the operator put it. It renders no ephemeral-storage request at all: the 2Gi request in
footprint.yaml is the API server defaulting an absent request to the limit
(scripts/generate_chart_footprint.py models the same rule), and that defaulting follows the
override's limit, so `limits: {ephemeral-storage: 10Gi}` alone is a 10Gi request too. Summing
it at 2Gi would pass a quota the pod is then refused on. kube-agents.workloadResources
applies the request-follows-limit rule to every key, which is right for a chart workload
whose requests the values own and wrong for the two the operator renders, so it is not
reused here. Takes (dict "workload" <footprint entry> "override" <resources block>) and
returns the entry's six numbers and pod count as JSON.
*/}}
{{- define "kube-agents.credentialProxyFootprint" -}}
{{- $workload := .workload | default dict -}}
{{- $override := .override | default dict -}}
{{- include "kube-agents.credentialProxyResourcesCheck" $override -}}
{{- $req := (index $override "requests") | default dict -}}
{{- $lim := (index $override "limits") | default dict -}}
{{- $cpuReq := $workload.cpuMillisRequest | default 0 | int64 -}}
{{- $cpuLim := $workload.cpuMillisLimit | default 0 | int64 -}}
{{- $memReq := $workload.memoryBytesRequest | default 0 | int64 -}}
{{- $memLim := $workload.memoryBytesLimit | default 0 | int64 -}}
{{- $ephReq := $workload.ephemeralStorageBytesRequest | default 0 | int64 -}}
{{- $ephLim := $workload.ephemeralStorageBytesLimit | default 0 | int64 -}}
{{- /* declaredQuantity with an empty fallback answers "" for an absent or null key, which
       `with` skips, so `memory: null` keeps the default as it does on the CR. */ -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $req "cpu") "fallback" "") -}}
{{- $cpuReq = include "kube-agents.parseCpuMillis" . | int64 -}}
{{- end -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $lim "cpu") "fallback" "") -}}
{{- $cpuLim = include "kube-agents.parseCpuMillis" . | int64 -}}
{{- end -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $req "memory") "fallback" "") -}}
{{- $memReq = include "kube-agents.parseBytes" . | int64 -}}
{{- end -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $lim "memory") "fallback" "") -}}
{{- $memLim = include "kube-agents.parseBytes" . | int64 -}}
{{- end -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $lim "ephemeral-storage") "fallback" "") -}}
{{- $ephLim = include "kube-agents.parseBytes" . | int64 -}}
{{- /* No operator-rendered request to keep: the API server sets it to this limit. */ -}}
{{- $ephReq = $ephLim -}}
{{- end -}}
{{- with include "kube-agents.declaredQuantity" (dict "value" (index $req "ephemeral-storage") "fallback" "") -}}
{{- $ephReq = include "kube-agents.parseBytes" . | int64 -}}
{{- end -}}
{{- dict
      "cpuMillisRequest" $cpuReq "cpuMillisLimit" $cpuLim
      "memoryBytesRequest" $memReq "memoryBytesLimit" $memLim
      "ephemeralStorageBytesRequest" $ephReq "ephemeralStorageBytesLimit" $ephLim
      "pods" ($workload.pods | default 1 | int64)
   | toJson -}}
{{- end }}

{{/*
The credential-proxy container's default requests and limits, and the smallest memory limit the
operator accepts, for the CR template's static check of
platformAgent.deployment.credentialProxy.resources. Copies of the operator's:
credentialProxyCPURequest, credentialProxyMemoryRequest, credentialProxyCPULimit,
credentialProxyMemoryLimit and credentialProxyEphemeralStorageLimit, and
credentialProxyMemoryFloorBytesAtDefaultCap, credentialProxyMinimumMemoryLimitBytes at the
default output cap, 672Mi (k8s-operator/internal/controller/credential_proxy_manifests.go).
tests/test_credential_proxy_sizing_parity.py holds them equal, the floor to the operator's and
the broker's declared copies; each side's own test holds its copy to its formula. Change all
sides together.
The defaults carry no ephemeral-storage request because the operator renders none.
*/}}
{{- define "kube-agents.credentialProxyDefaults" -}}
{{- dict
      "requests" (dict "cpu" "500m" "memory" "1Gi")
      "limits" (dict "cpu" "1" "memory" "2Gi" "ephemeral-storage" "2Gi")
   | toJson -}}
{{- end }}

{{- /* The agent-api-auth sidecar's defaults, the agentAPIAuth* constants in
       k8s-operator/internal/controller/platformagent_manifests.go. Declared once so
       the footprint delta reads them here rather than as scattered literals;
       tests/test_agent_api_auth_sizing_parity.py holds this equal to the operator. */ -}}
{{- define "kube-agents.agentAPIAuthDefaults" -}}
{{- dict
      "requests" (dict "cpu" "150m" "memory" "384Mi")
      "limits" (dict "cpu" "1" "memory" "2Gi" "ephemeral-storage" "2Gi")
   | toJson -}}
{{- end }}

{{- define "kube-agents.agentAPIAuthResourcesCheck" -}}
{{- include "kube-agents.containerResourcesCheck" (dict "resources" . "prefix" "platformAgent.deployment.agentAPIAuth.resources" "container" "agent-api-auth" "pod" "gateway pod" "consumer" "event watcher") -}}
{{- end }}

{{- define "kube-agents.credentialProxyMemoryFloorBytes" -}}
704643072
{{- end }}

{{- define "kube-agents.quotaRequirements" -}}
{{- $footprint := .Files.Get "files/footprint.yaml" | fromYaml -}}
{{- /* The footprint is the only source for the operator-rendered pods, which are most of
       the release. If it is missing or unparseable every one of them silently counts as
       zero and the preflight waves through a quota that cannot fit the release — the exact
       failure it exists to prevent, now with a green light in front of it. */ -}}
{{- if not (index $footprint "operatorRendered") -}}
  {{- fail "quota preflight: footprint.yaml is missing or unreadable in the chart, so the operator-rendered pods cannot be sized. Reinstall from an intact chart, or set quotaPreflight.enabled=false to skip the check." -}}
{{- end -}}
{{- $op := (index $footprint "operatorRendered") | default dict -}}

{{- $reqPods := 0 -}}
{{- $reqCpu := 0 -}}
{{- $limCpu := 0 -}}
{{- $reqMem := 0 -}}
{{- $limMem := 0 -}}
{{- $reqEph := 0 -}}
{{- $limEph := 0 -}}
{{- $reqPvc := 0 -}}
{{- $reqStorage := 0 -}}

{{- /* Largest single pod among the workloads that roll with a surge Pod. Used only to size
       the remediation patch, never the pass/fail threshold: a quota raised to exactly
       used+required fits the release at rest and then stalls its first rollout, which is the
       failure values.yaml warns about under hindsight.api.rollingUpdate. Rollouts are
       per-workload, so room for one surge Pod at a time is enough. */ -}}
{{- $surgeCpuReq := 0 -}}
{{- $surgeCpuLim := 0 -}}
{{- $surgeMemReq := 0 -}}
{{- $surgeMemLim := 0 -}}
{{- $surgeEphReq := 0 -}}
{{- $surgeEphLim := 0 -}}

{{- /* The chart's own workloads, as (resources subtree, pod count, rolls-with-a-surge-Pod).
       One list and one loop rather than a block each: the four blocks this replaced were
       identical but for the values path, which is how the dashboard came to be read from
       the wrong key and how a new workload comes to be missed. `hindsight.postgresql` is a
       StatefulSet, so it contributes no surge Pod. The pre-delete cleanup hook is a batch
       Job that runs at uninstall while the release still stands, so it needs headroom but
       no surge. */ -}}
{{- $chartWorkloads := list -}}
{{- if .Values.operator.enabled -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" .Values.operator "pods" (include "kube-agents.replicaCount" .Values.operator.replicaCount | int64) "surges" true) -}}
{{- end -}}
{{- if .Values.litellm.enabled -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" .Values.litellm "pods" (include "kube-agents.replicaCount" .Values.litellm.replicaCount | int64) "surges" true) -}}
{{- end -}}
{{- if include "kube-agents.hindsightEnabled" . -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" .Values.hindsight.api "pods" 1 "surges" true) -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" .Values.hindsight.postgresql "pods" 1 "surges" false) -}}
{{- end -}}
{{- if .Values.githubMinter.enabled -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" .Values.githubMinter "pods" (include "kube-agents.replicaCount" .Values.githubMinter.replicaCount | int64) "surges" true) -}}
{{- end -}}
{{- if and .Values.platformAgent.enabled .Values.platformAgent.cleanupHook.enabled -}}
  {{- /* Pre-delete hook Job in templates/platform-agent-cr-cleanup.yaml: runs at helm uninstall
         while every release pod still exists, so quota admission needs headroom for it. */ -}}
  {{- $cleanupRes := dict "resources" (dict "requests" (dict "cpu" "50m" "memory" "64Mi") "limits" (dict "cpu" "200m" "memory" "128Mi")) -}}
  {{- $chartWorkloads = append $chartWorkloads (dict "values" $cleanupRes "pods" 1 "surges" false) -}}
{{- end -}}

{{- range $workload := $chartWorkloads -}}
  {{- $res := include "kube-agents.workloadResources" $workload.values | fromJson -}}
  {{- $replicas := $workload.pods | int64 -}}
  {{- $reqPods = add $reqPods $replicas -}}
  {{- $reqCpu = add $reqCpu (mul $res.cpuRequest $replicas) -}}
  {{- $limCpu = add $limCpu (mul $res.cpuLimit $replicas) -}}
  {{- $reqMem = add $reqMem (mul $res.memoryRequest $replicas) -}}
  {{- $limMem = add $limMem (mul $res.memoryLimit $replicas) -}}
  {{- $reqEph = add $reqEph (mul $res.ephemeralRequest $replicas) -}}
  {{- $limEph = add $limEph (mul $res.ephemeralLimit $replicas) -}}
  {{- /* A workload scaled to zero has no pod to surge from, so it sizes no patch. */ -}}
  {{- if and $workload.surges (gt $replicas (int64 0)) -}}
    {{- $surgeCpuReq = max $surgeCpuReq $res.cpuRequest -}}
    {{- $surgeCpuLim = max $surgeCpuLim $res.cpuLimit -}}
    {{- $surgeMemReq = max $surgeMemReq $res.memoryRequest -}}
    {{- $surgeMemLim = max $surgeMemLim $res.memoryLimit -}}
    {{- $surgeEphReq = max $surgeEphReq $res.ephemeralRequest -}}
    {{- $surgeEphLim = max $surgeEphLim $res.ephemeralLimit -}}
  {{- end -}}
{{- end -}}

{{- /* Hindsight's PostgreSQL claim, from the same key templates/hindsight.yaml renders the
       volumeClaimTemplate request from. */ -}}
{{- if include "kube-agents.hindsightEnabled" . -}}
  {{- $pgStorage := .Values.hindsight.postgresql.storage -}}
  {{- /* values.schema.json closes hindsight.postgresql to image, resources and storage, but
         `additionalProperties: false` rejects extra keys rather than requiring the ones
         listed, and the schema has no `required` anywhere. So `storage: null` is valid
         input that parses as 0 and under-counts requests.storage by the whole claim,
         passing a quota that cannot hold it. The StatefulSet would render an empty request
         from the same key, so failing here is the honest answer. */ -}}
  {{- if or (kindIs "invalid" $pgStorage) (eq (toString $pgStorage) "") -}}
    {{- fail "quota preflight: hindsight.postgresql.storage is empty, so the PostgreSQL claim cannot be sized. Set it to the size the StatefulSet should request, or set quotaPreflight.enabled=false to skip the check." -}}
  {{- end -}}
  {{- $reqPvc = add $reqPvc 1 -}}
  {{- $reqStorage = add $reqStorage (include "kube-agents.parseBytes" $pgStorage | int64) -}}
{{- end -}}

{{- /* Operator-rendered workloads (footprint.yaml) */ -}}
{{- if .Values.platformAgent.enabled -}}
  {{- /* The agent pod is the one operator-rendered workload that scales: the gateway
         Deployment takes spec.replicas from availability.replicas, while the shell
         StatefulSet and the credential proxy stay at 1 (see the platformagent-ha golden,
         where the gateway goes to 3 and the other two do not). The footprint records one
         pod's worth, so it is multiplied here — without this an HA install passes the
         check and then leaves its extra replicas Pending, which is the failure this
         whole template exists to prevent. An absent value means the operator's own
         default of 1; an explicit 0 means 0, and the CRD allows it. */ -}}
  {{- $agentReplicas := include "kube-agents.replicaCount" (((.Values.platformAgent.deployment | default dict).availability | default dict).replicas) | int64 -}}
  {{- $base := (index $op "agentPod" "base") | default dict -}}
  {{- $podReqCpu := $base.cpuMillisRequest | default 0 | int64 -}}
  {{- $podLimCpu := $base.cpuMillisLimit | default 0 | int64 -}}
  {{- $podReqMem := $base.memoryBytesRequest | default 0 | int64 -}}
  {{- $podLimMem := $base.memoryBytesLimit | default 0 | int64 -}}
  {{- $podReqEph := $base.ephemeralStorageBytesRequest | default 0 | int64 -}}
  {{- $podLimEph := $base.ephemeralStorageBytesLimit | default 0 | int64 -}}

  {{- /* The agent-api-auth sidecar is one container of this pod, so its default
         requests and limits are already in agentPod.base above. A
         spec.deployment.agentAPIAuth.resources override (resolveAgentAPIAuthResources
         in the operator) changes them per key, so add the override-minus-default
         delta here before the pod is multiplied by replicas, the same accounting
         kube-agents.credentialProxyFootprint does for the proxy's own pod. Without
         it the preflight passes a quota the raised sidecar will not fit, and the
         gateway's Recreate rollout then deletes the running Pod before the quota
         refuses the larger one. The defaults are the agentAPIAuth* constants in
         k8s-operator/internal/controller/platformagent_manifests.go: 150m and 384Mi
         requests, 1 CPU, 2Gi memory and 2Gi ephemeral-storage limits; the sidecar
         declares no ephemeral request, which the API server defaults to the limit,
         so the base counts 2Gi on both ephemeral sides. */ -}}
  {{- $aaResources := (((.Values.platformAgent.deployment | default dict).agentAPIAuth | default dict).resources) | default dict -}}
  {{- include "kube-agents.agentAPIAuthResourcesCheck" $aaResources -}}
  {{- $aaReq := (index $aaResources "requests") | default dict -}}
  {{- $aaLim := (index $aaResources "limits") | default dict -}}
  {{- $aaDefaults := include "kube-agents.agentAPIAuthDefaults" . | fromJson -}}
  {{- $aaReqDef := index $aaDefaults "requests" -}}
  {{- $aaLimDef := index $aaDefaults "limits" -}}
  {{- /* Default sidecar figures as the numbers the footprint uses. */ -}}
  {{- $defCpuReq := include "kube-agents.parseCpuMillis" (index $aaReqDef "cpu") | int64 -}}
  {{- $defCpuLim := include "kube-agents.parseCpuMillis" (index $aaLimDef "cpu") | int64 -}}
  {{- $defMemReq := include "kube-agents.parseBytes" (index $aaReqDef "memory") | int64 -}}
  {{- $defMemLim := include "kube-agents.parseBytes" (index $aaLimDef "memory") | int64 -}}
  {{- $defEph := include "kube-agents.parseBytes" (index $aaLimDef "ephemeral-storage") | int64 -}}
  {{- /* Merged over the defaults, the pod the operator would render. The sidecar declares
         no ephemeral request, which the API server defaults to the limit, so both ephemeral
         sides start at the default limit and the request follows an override of the limit
         unless set explicitly. */ -}}
  {{- $mCpuReq := $defCpuReq -}}{{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "cpu") "fallback" "") -}}{{- $mCpuReq = include "kube-agents.parseCpuMillis" . | int64 -}}{{- end -}}
  {{- $mCpuLim := $defCpuLim -}}{{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "cpu") "fallback" "") -}}{{- $mCpuLim = include "kube-agents.parseCpuMillis" . | int64 -}}{{- end -}}
  {{- $mMemReq := $defMemReq -}}{{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "memory") "fallback" "") -}}{{- $mMemReq = include "kube-agents.parseBytes" . | int64 -}}{{- end -}}
  {{- $mMemLim := $defMemLim -}}{{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "memory") "fallback" "") -}}{{- $mMemLim = include "kube-agents.parseBytes" . | int64 -}}{{- end -}}
  {{- $mEphLim := $defEph -}}{{- $mEphReq := $defEph -}}
  {{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "ephemeral-storage") "fallback" "") -}}{{- $mEphLim = include "kube-agents.parseBytes" . | int64 -}}{{- $mEphReq = $mEphLim -}}{{- end -}}
  {{- with include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "ephemeral-storage") "fallback" "") -}}{{- $mEphReq = include "kube-agents.parseBytes" . | int64 -}}{{- end -}}
  {{- /* The operator refuses a zero limit or a request above its limit (validateContainerResources)
         and renders the sidecar at its defaults, Degraded. agentAPIAuthResourcesCheck above does not
         refuse those -- they stay the operator's and the webhook's -- so the preflight must count the
         override's delta only for an override the operator will actually render, or it under- or
         over-counts the pod against the quota the operator never asks for. */ -}}
  {{- /* The refusal is the operator's exact resource.Quantity comparison, so it reads the
         merged raw quantities through kube-agents.quantityExact rather than the rounded
         $mMemLim/$mMemReq integers above: parseBytes and parseCpuMillis ceil an m/u/n
         quantity, so a limit half a byte under a default request rounds up onto it and the
         integer gate would miss a crossed pair the operator refuses. The proxy's CR block
         decides the same thing on the same exact figures (platform-agent-cr.yaml). The
         rounded integers stay the quota-sum arithmetic, which wants the whole-byte figure. */ -}}
  {{- $mCpuLimRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "cpu") "fallback" (index $aaLimDef "cpu")) -}}
  {{- $mCpuReqRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "cpu") "fallback" (index $aaReqDef "cpu")) -}}
  {{- $mMemLimRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "memory") "fallback" (index $aaLimDef "memory")) -}}
  {{- $mMemReqRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "memory") "fallback" (index $aaReqDef "memory")) -}}
  {{- $mEphLimRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaLim "ephemeral-storage") "fallback" (index $aaLimDef "ephemeral-storage")) -}}
  {{- $mEphReqRaw := include "kube-agents.declaredQuantity" (dict "value" (index $aaReq "ephemeral-storage") "fallback" $mEphLimRaw) -}}
  {{- $xCpuLim := include "kube-agents.quantityExact" (dict "raw" $mCpuLimRaw "cpu" true "key" "platformAgent.deployment.agentAPIAuth.resources.limits.cpu") | float64 -}}
  {{- $xCpuReq := include "kube-agents.quantityExact" (dict "raw" $mCpuReqRaw "cpu" true "key" "platformAgent.deployment.agentAPIAuth.resources.requests.cpu") | float64 -}}
  {{- $xMemLim := include "kube-agents.quantityExact" (dict "raw" $mMemLimRaw "cpu" false "key" "platformAgent.deployment.agentAPIAuth.resources.limits.memory") | float64 -}}
  {{- $xMemReq := include "kube-agents.quantityExact" (dict "raw" $mMemReqRaw "cpu" false "key" "platformAgent.deployment.agentAPIAuth.resources.requests.memory") | float64 -}}
  {{- $xEphLim := include "kube-agents.quantityExact" (dict "raw" $mEphLimRaw "cpu" false "key" "platformAgent.deployment.agentAPIAuth.resources.limits.ephemeral-storage") | float64 -}}
  {{- $xEphReq := include "kube-agents.quantityExact" (dict "raw" $mEphReqRaw "cpu" false "key" "platformAgent.deployment.agentAPIAuth.resources.requests.ephemeral-storage") | float64 -}}
  {{- $aaRefused := false -}}
  {{- if or (eq $xCpuLim 0.0) (eq $xMemLim 0.0) (eq $xEphLim 0.0) -}}{{- $aaRefused = true -}}{{- end -}}
  {{- if or (gt $xCpuReq $xCpuLim) (gt $xMemReq $xMemLim) (gt $xEphReq $xEphLim) -}}{{- $aaRefused = true -}}{{- end -}}
  {{- if not $aaRefused -}}
  {{- /* satAdd, not add: an admitted sidecar limit near 2^63 carries the pod sum past
         int64 and would wrap `required` negative. The sub stays plain -- a merged
         figure minus its default is always below the merged figure and cannot wrap. */ -}}
  {{- $podReqCpu = include "kube-agents.satAdd" (dict "a" $podReqCpu "b" (sub $mCpuReq $defCpuReq)) | int64 -}}
  {{- $podLimCpu = include "kube-agents.satAdd" (dict "a" $podLimCpu "b" (sub $mCpuLim $defCpuLim)) | int64 -}}
  {{- $podReqMem = include "kube-agents.satAdd" (dict "a" $podReqMem "b" (sub $mMemReq $defMemReq)) | int64 -}}
  {{- $podLimMem = include "kube-agents.satAdd" (dict "a" $podLimMem "b" (sub $mMemLim $defMemLim)) | int64 -}}
  {{- $podLimEph = include "kube-agents.satAdd" (dict "a" $podLimEph "b" (sub $mEphLim $defEph)) | int64 -}}
  {{- $podReqEph = include "kube-agents.satAdd" (dict "a" $podReqEph "b" (sub $mEphReq $defEph)) | int64 -}}
  {{- end -}}

  {{- /* The dashboard is another container in the agent pod rather than a pod of its own,
         so it scales with the same replica count and adds no pod. Its flag is
         harness.hermes.dashboardEnabled; reading it one level up at harness.dashboardEnabled
         matches nothing, leaves this branch dead, and counts the dashboard even when it is
         switched off. `null` there means "no opinion", so the CRD default (true) applies. */ -}}
  {{- $hermes := (index (.Values.platformAgent.harness | default dict) "hermes") | default dict -}}
  {{- $dashEnabled := true -}}
  {{- if kindIs "bool" (index $hermes "dashboardEnabled") -}}
    {{- $dashEnabled = index $hermes "dashboardEnabled" -}}
  {{- end -}}
  {{- if $dashEnabled -}}
    {{- $dash := (index $op "agentPod" "dashboard") | default dict -}}
    {{- /* satAdd: the pod sum above may already be the saturated ceiling from a huge
           sidecar override, which a plain add would wrap. */ -}}
    {{- $podReqCpu = include "kube-agents.satAdd" (dict "a" $podReqCpu "b" ($dash.cpuMillisRequest | default 0 | int64)) | int64 -}}
    {{- $podLimCpu = include "kube-agents.satAdd" (dict "a" $podLimCpu "b" ($dash.cpuMillisLimit | default 0 | int64)) | int64 -}}
    {{- $podReqMem = include "kube-agents.satAdd" (dict "a" $podReqMem "b" ($dash.memoryBytesRequest | default 0 | int64)) | int64 -}}
    {{- $podLimMem = include "kube-agents.satAdd" (dict "a" $podLimMem "b" ($dash.memoryBytesLimit | default 0 | int64)) | int64 -}}
    {{- $podReqEph = include "kube-agents.satAdd" (dict "a" $podReqEph "b" ($dash.ephemeralStorageBytesRequest | default 0 | int64)) | int64 -}}
    {{- $podLimEph = include "kube-agents.satAdd" (dict "a" $podLimEph "b" ($dash.ephemeralStorageBytesLimit | default 0 | int64)) | int64 -}}
  {{- end -}}

  {{- /* satMul/satAdd: the pod sum times the replica count is where an admitted
         override most easily passes int64 -- a figure under 2^63 doubles over it at
         two replicas -- so both the multiply and the accumulation saturate. */ -}}
  {{- $reqPods = include "kube-agents.satAdd" (dict "a" $reqPods "b" (include "kube-agents.satMul" (dict "a" ($base.pods | default 1 | int64) "b" $agentReplicas))) | int64 -}}
  {{- $reqCpu = include "kube-agents.satAdd" (dict "a" $reqCpu "b" (include "kube-agents.satMul" (dict "a" $podReqCpu "b" $agentReplicas))) | int64 -}}
  {{- $limCpu = include "kube-agents.satAdd" (dict "a" $limCpu "b" (include "kube-agents.satMul" (dict "a" $podLimCpu "b" $agentReplicas))) | int64 -}}
  {{- $reqMem = include "kube-agents.satAdd" (dict "a" $reqMem "b" (include "kube-agents.satMul" (dict "a" $podReqMem "b" $agentReplicas))) | int64 -}}
  {{- $limMem = include "kube-agents.satAdd" (dict "a" $limMem "b" (include "kube-agents.satMul" (dict "a" $podLimMem "b" $agentReplicas))) | int64 -}}
  {{- $reqEph = include "kube-agents.satAdd" (dict "a" $reqEph "b" (include "kube-agents.satMul" (dict "a" $podReqEph "b" $agentReplicas))) | int64 -}}
  {{- $limEph = include "kube-agents.satAdd" (dict "a" $limEph "b" (include "kube-agents.satMul" (dict "a" $podLimEph "b" $agentReplicas))) | int64 -}}
  {{- /* Only an HA gateway surges. The operator gives the gateway Deployment a
         RollingUpdate strategy only when availability.replicas is above 1 and renders
         `strategy: Recreate` otherwise (resolveDeploymentReplicasAndStrategy in
         k8s-operator/internal/controller/manifest_helpers.go; the default-CR golden
         platformagent.yaml shows Recreate, the platformagent-ha one RollingUpdate). A
         Recreate rollout deletes the old Pod before creating the new one, so it needs no
         extra room. Counting the agent pod here at one replica made it win the max on
         every default install — it is the largest workload in the release — and the
         printed patch then asked for an agent pod's worth of CPU, memory and ephemeral
         storage that the release can never consume. */ -}}
  {{- if gt $agentReplicas (int64 1) -}}
    {{- $surgeCpuReq = max $surgeCpuReq $podReqCpu -}}
    {{- $surgeCpuLim = max $surgeCpuLim $podLimCpu -}}
    {{- $surgeMemReq = max $surgeMemReq $podReqMem -}}
    {{- $surgeMemLim = max $surgeMemLim $podLimMem -}}
    {{- $surgeEphReq = max $surgeEphReq $podReqEph -}}
    {{- $surgeEphLim = max $surgeEphLim $podLimEph -}}
  {{- end -}}

  {{- /* Workloads rendered by the operator outside the agent pod (e.g. shellSandbox,
         credentialProxy, and any future workload added to operatorRendered). Iterating
         generic keys here ensures that any workload summed into extract_footprint is
         automatically counted by the preflight without requiring manual template edits.
         agentPod and storage are handled separately above and below. */ -}}
  {{- /* The credential proxy is the one operator-rendered workload of its own pod with a
         sizing override: its footprint entry takes platformAgent.deployment.credentialProxy.resources
         over it per key (kube-agents.credentialProxyFootprint) before it is summed, so a
         raised memory limit is counted here as the pod the operator will write, rather than
         the preflight passing a quota the release will not fit. An ephemeral-storage limit
         set alone is counted as a request of that size too: the operator renders no
         ephemeral-storage request and the API server defaults it to the limit. The
         agent-api-auth sidecar has a sizing override too, but it is a container of the agent
         pod, so its delta is added to agentPod above rather than counted here. */ -}}
  {{- $proxyOverride := (((.Values.platformAgent.deployment | default dict).credentialProxy | default dict).resources) | default dict -}}
  {{- range $key, $workload := $op -}}
    {{- if and (ne $key "agentPod") (ne $key "storage") -}}
      {{- if and (eq $key "credentialProxy") $proxyOverride -}}
        {{- $workload = include "kube-agents.credentialProxyFootprint" (dict "workload" $workload "override" $proxyOverride) | fromJson -}}
      {{- end -}}
      {{- /* satAdd: a total above may already be the saturated ceiling from a huge
             agent-pod override, which a plain add here would wrap back negative. */ -}}
      {{- $reqPods = include "kube-agents.satAdd" (dict "a" $reqPods "b" (include "kube-agents.replicaCount" $workload.pods | int64)) | int64 -}}
      {{- $reqCpu = include "kube-agents.satAdd" (dict "a" $reqCpu "b" ($workload.cpuMillisRequest | default 0 | int64)) | int64 -}}
      {{- $limCpu = include "kube-agents.satAdd" (dict "a" $limCpu "b" ($workload.cpuMillisLimit | default 0 | int64)) | int64 -}}
      {{- $reqMem = include "kube-agents.satAdd" (dict "a" $reqMem "b" ($workload.memoryBytesRequest | default 0 | int64)) | int64 -}}
      {{- $limMem = include "kube-agents.satAdd" (dict "a" $limMem "b" ($workload.memoryBytesLimit | default 0 | int64)) | int64 -}}
      {{- $reqEph = include "kube-agents.satAdd" (dict "a" $reqEph "b" ($workload.ephemeralStorageBytesRequest | default 0 | int64)) | int64 -}}
      {{- $limEph = include "kube-agents.satAdd" (dict "a" $limEph "b" ($workload.ephemeralStorageBytesLimit | default 0 | int64)) | int64 -}}
    {{- end -}}
  {{- end -}}

  {{- /* Claims are release-scoped rather than per-replica, so they are not multiplied. */ -}}
  {{- $storage := (index $op "storage") | default dict -}}
  {{- $reqPvc = add $reqPvc ($storage.persistentVolumeClaims | default 0 | int64) -}}
  {{- $reqStorage = add $reqStorage ($storage.storageBytesRequest | default 0 | int64) -}}
{{- end -}}

{{- dict
      "pods" $reqPods
      "requestsCpu" $reqCpu "limitsCpu" $limCpu
      "requestsMemory" $reqMem "limitsMemory" $limMem
      "requestsEphemeral" $reqEph "limitsEphemeral" $limEph
      "persistentVolumeClaims" $reqPvc "requestsStorage" $reqStorage
      "surgeRequestsCpu" $surgeCpuReq "surgeLimitsCpu" $surgeCpuLim
      "surgeRequestsMemory" $surgeMemReq "surgeLimitsMemory" $surgeMemLim
      "surgeRequestsEphemeral" $surgeEphReq "surgeLimitsEphemeral" $surgeEphLim
   | toJson -}}
{{- end }}

{{- define "kube-agents.quotaCheckItems" -}}
{{- $ctx := .ctx -}}
{{- $r := .required -}}
{{- /* Every deficient quota, not the first one. `fail` inside the loop reported one quota
       per render, so a namespace with two of them was a patch-and-retry cycle — and the
       whole value of this check is telling the operator what to fix in one pass. */ -}}
{{- $quotaReports := list -}}
{{- range $quota := .items -}}
  {{- $spec := index $quota "spec" | default dict -}}
  {{- $scopes := index $spec "scopes" -}}
  {{- $scopeSelector := index $spec "scopeSelector" -}}
  {{- if or $scopes $scopeSelector -}}
    {{- /* Scoped quota: it applies to a subset of pods this template cannot identify, so
           comparing the whole release against it would be wrong in both directions. */ -}}
  {{- else -}}
    {{- $hard := index $spec "hard" | default dict -}}
    {{- $status := index $quota "status" | default dict -}}
    {{- $used := index $status "used" | default dict -}}
    {{- $shortfalls := list -}}
    {{- $patchEntries := list -}}
    {{- $constrainsEphemeral := false -}}

    {{- range $key, $hardRaw := $hard -}}
      {{- if or (eq $key "limits.ephemeral-storage") (eq $key "requests.ephemeral-storage") (eq $key "ephemeral-storage") -}}
        {{- $constrainsEphemeral = true -}}
      {{- end -}}
      {{- $req := 0 -}}
      {{- /* Named $surgeRoom rather than the fencepost name used by
             kube-agents.rollingUpdateFenceposts: tests/test_deployments_rollout_quota.py
             scans this whole file for an unguarded reassignment of that name, which would be
             a rollingUpdate fencepost pinned for every install. This is a different quantity
             — the headroom the remediation patch leaves — and sharing the name would make
             that check unreadable. */ -}}
      {{- $surgeRoom := 0 -}}
      {{- $isCpu := false -}}
      {{- $isBytes := false -}}
      {{- $isCount := false -}}
      {{- /* Claim-shaped keys. A PersistentVolumeClaim outlives the release that created it:
             the shell StatefulSet sets persistentVolumeClaimRetentionPolicy Retain/Retain, so
             `helm uninstall` leaves its claims behind and they appear in `used` on the next
             install — claims this release will reuse by name rather than create again.
             Charging them twice refused a reinstall into a namespace sized exactly for the
             release, and the patch it printed asked for 50% more claims than the release
             will ever hold. `hard` still has to fit the release, which is the comparison
             that catches a quota genuinely too small. */ -}}
      {{- $isClaimShaped := false -}}

      {{- if eq $key "limits.cpu" -}}
        {{- $req = int64 $r.limitsCpu -}}
        {{- $surgeRoom = int64 $r.surgeLimitsCpu -}}
        {{- $isCpu = true -}}
      {{- else if or (eq $key "requests.cpu") (eq $key "cpu") -}}
        {{- $req = int64 $r.requestsCpu -}}
        {{- $surgeRoom = int64 $r.surgeRequestsCpu -}}
        {{- $isCpu = true -}}
      {{- else if eq $key "limits.memory" -}}
        {{- $req = int64 $r.limitsMemory -}}
        {{- $surgeRoom = int64 $r.surgeLimitsMemory -}}
        {{- $isBytes = true -}}
      {{- else if or (eq $key "requests.memory") (eq $key "memory") -}}
        {{- $req = int64 $r.requestsMemory -}}
        {{- $surgeRoom = int64 $r.surgeRequestsMemory -}}
        {{- $isBytes = true -}}
      {{- else if eq $key "limits.ephemeral-storage" -}}
        {{- $req = int64 $r.limitsEphemeral -}}
        {{- /* A surge Pod brings its ephemeral storage with it, same as its CPU and memory. */ -}}
        {{- $surgeRoom = int64 $r.surgeLimitsEphemeral -}}
        {{- $isBytes = true -}}
      {{- else if or (eq $key "requests.ephemeral-storage") (eq $key "ephemeral-storage") -}}
        {{- $req = int64 $r.requestsEphemeral -}}
        {{- $surgeRoom = int64 $r.surgeRequestsEphemeral -}}
        {{- $isBytes = true -}}
      {{- else if or (eq $key "requests.storage") (eq $key "storage") -}}
        {{- $req = int64 $r.requestsStorage -}}
        {{- /* No surge room: a surge Pod mounts the existing claim rather than creating one. */ -}}
        {{- $isBytes = true -}}
        {{- $isClaimShaped = true -}}
      {{- else if or (eq $key "pods") (eq $key "count/pods") -}}
        {{- $req = int64 $r.pods -}}
        {{- /* One surge Pod, for the same reason as the CPU and memory surge. */ -}}
        {{- $surgeRoom = 1 -}}
        {{- $isCount = true -}}
      {{- else if or (eq $key "persistentvolumeclaims") (eq $key "count/persistentvolumeclaims") -}}
        {{- $req = int64 $r.persistentVolumeClaims -}}
        {{- $isCount = true -}}
        {{- $isClaimShaped = true -}}
      {{- end -}}

      {{- if or $isCpu $isBytes $isCount -}}
        {{- $hardVal := 0 -}}
        {{- $usedVal := 0 -}}
        {{- if $isCpu -}}
          {{- $hardVal = include "kube-agents.parseCpuMillis" $hardRaw | int64 -}}
          {{- $usedVal = include "kube-agents.parseCpuMillis" (index $used $key | default "0") | int64 -}}
        {{- else if $isBytes -}}
          {{- $hardVal = include "kube-agents.parseBytes" $hardRaw | int64 -}}
          {{- $usedVal = include "kube-agents.parseBytes" (index $used $key | default "0") | int64 -}}
        {{- else if $isCount -}}
          {{- $hardVal = include "kube-agents.parseCount" $hardRaw | int64 -}}
          {{- $usedVal = include "kube-agents.parseCount" (index $used $key | default "0") | int64 -}}
        {{- end -}}

        {{- $availVal := sub $hardVal $usedVal -}}
        {{- $failed := false -}}
        {{- $reason := "" -}}

        {{- if lt $hardVal $req -}}
          {{- $failed = true -}}
          {{- $reason = "quota hard capacity is less than required" -}}
        {{- else if and $ctx.Release.IsInstall (not $isClaimShaped) (lt $availVal $req) -}}
          {{- $failed = true -}}
          {{- $reason = "available headroom (hard - used) is less than required for fresh install" -}}
        {{- end -}}

        {{- if $failed -}}
          {{- $patchTarget := 0 -}}
          {{- if and $ctx.Release.IsInstall (not $isClaimShaped) -}}
            {{- /* used + required + one surge Pod. Exactly used+required fits the release at
                   rest and then stalls its first rolling update. */ -}}
            {{- $patchTarget = add $usedVal $req $surgeRoom -}}
          {{- else -}}
            {{- /* On upgrade — and for claim-shaped keys on install, where retained PVCs from a
                   previous install may already sit in `used` — adding `used` asks for the
                   release twice: a release needing 6 pods with 4 running was told to patch to
                   11 where 7 does, and a 22Gi claim requirement with 22Gi retained asked for
                   44Gi. What a neighbouring workload holds is in `used` too and cannot be told
                   apart from the release's own, so this is the release's need plus a surge Pod
                   — right in a namespace the release has to itself, and short by the neighbours'
                   share in one it does not. */ -}}
            {{- $patchTarget = add $req $surgeRoom -}}
          {{- end -}}
          {{- $reqFormatted := "" -}}
          {{- $hardFormatted := "" -}}
          {{- $availFormatted := "" -}}
          {{- $patchVal := "" -}}
          {{- if $isCpu -}}
            {{- $reqFormatted = include "kube-agents.formatCpu" $req -}}
            {{- $hardFormatted = include "kube-agents.formatCpu" $hardVal -}}
            {{- $availFormatted = include "kube-agents.formatCpu" $availVal -}}
            {{- $patchVal = include "kube-agents.formatCpu" $patchTarget -}}
          {{- else if $isBytes -}}
            {{- $reqFormatted = include "kube-agents.formatBytesApprox" $req -}}
            {{- /* The quota's own spelling, not a re-rendering of it: `hard 10G` is what
                   `kubectl describe resourcequota` shows, so echoing it verbatim is both
                   shorter and easier to match up than any unit this could pick. */ -}}
            {{- $hardFormatted = toString $hardRaw -}}
            {{- $availFormatted = include "kube-agents.formatBytesApprox" $availVal -}}
            {{- $patchVal = include "kube-agents.formatBytesCeil" $patchTarget -}}
          {{- else -}}
            {{- $reqFormatted = printf "%d" $req -}}
            {{- $hardFormatted = printf "%d" $hardVal -}}
            {{- $availFormatted = printf "%d" $availVal -}}
            {{- $patchVal = printf "%d" $patchTarget -}}
          {{- end -}}

          {{- $line := printf "  - %s: required %s, hard %s, available %s (%s)" $key $reqFormatted $hardFormatted $availFormatted $reason -}}
          {{- $shortfalls = append $shortfalls $line -}}
          {{- $patchEntries = append $patchEntries (printf "%q:%q" $key $patchVal) -}}
        {{- end -}}
      {{- end -}}
    {{- end -}}

    {{- if gt (len $shortfalls) 0 -}}
      {{- $qName := (index (index $quota "metadata" | default dict) "name") | default "resourcequota" -}}
      {{- $patchBody := printf "{\"spec\":{\"hard\":{%s}}}" (join "," $patchEntries) -}}
      {{- $patchCmd := printf "kubectl patch resourcequota %s -n %s --type=strategic --patch '%s'" $qName $ctx.Release.Namespace $patchBody -}}
      {{- $ephNote := "" -}}
      {{- if $constrainsEphemeral -}}
        {{- $ephNote = printf "\n(a quota constraining ephemeral storage additionally requires a LimitRange in namespace %q providing default requests and limits, because chart workloads and operator containers omit them; without one, pod creation fails with 'must specify requests.ephemeral-storage')" $ctx.Release.Namespace -}}
      {{- end -}}
      {{- $report := printf "ResourceQuota %q in namespace %q has insufficient capacity for release %q:\n%s\n\nRemediation: increase the quota with:\n  %s\n(those values leave room for one rollout surge Pod, except for claim counts and storage, which a surge Pod does not add to)%s" $qName $ctx.Release.Namespace $ctx.Release.Name (join "\n" $shortfalls) $patchCmd $ephNote -}}
      {{- $quotaReports = append $quotaReports $report -}}
    {{- end -}}
  {{- end -}}
{{- end -}}
{{- if gt (len $quotaReports) 0 -}}
  {{- fail (printf "%s\n\nor bypass this check with --set quotaPreflight.enabled=false" (join "\n\n" $quotaReports)) -}}
{{- end -}}
{{- end }}

{{- define "kube-agents.quotaPreflight" -}}
{{- if .Values.quotaPreflight.enabled -}}
{{- $rawQuotas := lookup "v1" "ResourceQuota" .Release.Namespace "" -}}
{{- $quotas := $rawQuotas | default dict -}}
{{- $items := list -}}
{{- if kindIs "map" $quotas -}}
  {{- $items = index $quotas "items" | default list -}}
{{- end -}}
{{- if gt (len $items) 0 -}}
  {{- $required := include "kube-agents.quotaRequirements" . | fromJson -}}
  {{- include "kube-agents.quotaCheckItems" (dict "ctx" . "items" $items "required" $required) -}}
{{- end -}}
{{- end -}}
{{- end }}
